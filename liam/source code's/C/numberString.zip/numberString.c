#include <string.h>
#include <stdio.h>
int decimalPointPosition(const char *numStr);
int numLeadingZeros(const char *numStr);
int numTrailingZeros(const char *numStr);
int numStringIsInteger(const char *numStr);
double numStringToDouble(const char *numStr);
int standardizeNumString(char *numStr);
int numStringSum(const char *numStr1, const char *numStr2, char *numStrSum, int buffSize);
// optional main for testing the program =)
// void main()
// {
//     char buffer[50];
//     int ans = numStringSum("992345601", "943523001.23423",buffer,30);
//     for (int i = 0; i < 50; i++)
//     {
//         char t = buffer[i];
//         if (t == '\0')
//         {
//             break;
//         }

//         printf("%c", t);
//     }
//     printf("%d", ans);

// }
int numStringSum(const char *numStr1, const char *numStr2, char *numStrSum, int buffSize)
{
    int expectedOverFlow = -1;
    int carry = 0;
    char e = 0;
    // validating the 2 strings
    int valid1 = decimalPointPosition(numStr1);
    int valid2 = decimalPointPosition(numStr2);
    if (valid1 == -1 || valid2 == -1)
    {
        return 0;
    }
    int size1 = strlen(numStr1);
    int size2 = strlen(numStr2);
    // computing the size of the sum.
    int dot1 = -1;
    int dot2 = -1;
    if (valid1 != size1)
    {
        dot1 = 1;
    }
    if (valid2 != size2)
    {
        dot2 = 1;
    }
    // computing overHangR
    int overHangR = -1;
    // no dot in either
    if (dot1 == -1 && dot2 == -1)
    {
        overHangR = 0;
    }
    // dot in numstr1 no dot numstr2
    if (dot1 == 1 && dot2 == -1)
    {
        overHangR = size1 - valid1;
    }
    // dot in numstr2 no dot numstr1
    if (dot2 == 1 && dot1 == -1)
    {
        overHangR = size2 - valid2;
    }
    // dot in both
    int afterdot1 = -1;
    int afterdot2 = -1;
    if (dot1 == 1 && dot2 == 1)
    {
        afterdot1 = size1 - valid1 - 1;
        afterdot2 = size2 - valid2 - 1;
        if (afterdot1 >= afterdot2)
        {
            overHangR = afterdot1 - afterdot2;
        }
        else
        {
            overHangR = afterdot2 - afterdot1;
        }
    }
    // computing overHangL
    int overHangL = -1;
    if (dot1 == -1 && dot2 == -1)
    {
        if (size1 > size2)
        {
            overHangL = size1 - size2;
        }
        if (size2 > size1)
        {
            overHangL = size2 - size1;
        }
        if (size1 == size2)
        {
            overHangL = 0;
        }
    }
    if (dot1 == 1 && dot2 == -1)
    {
        if (size1 > size2)
        {
            if (size1 - overHangR > size2)
            {
                overHangL = size1 - overHangR - size2;
            }
            if (size1 - overHangR < size2)
            {
                overHangL = size2 - (size1 - overHangR);
            }
            if (size1 - overHangR == size2)
            {
                overHangL = 0;
            }
        }
        if (size2 >= size1)
        {
            overHangL = size2 - (size1 - overHangR);
        }
    }
    if (dot1 == -1 && dot2 == 1)
    {
        if (size1 >= size2)
        {
            overHangL = size1 - (size2 - overHangR);
        }
        if (size2 > size1)
        {
            if (size2 - overHangR > size1)
            {
                overHangL = size2 - size1 - overHangR;
            }
            if (size2 - overHangR < size1)
            {
                overHangL = size1 - (size2 - overHangR);
            }
            if (size2 - overHangR == size1)
            {
                overHangL = 0;
            }
        }
    }
    if (dot1 == 1 && dot2 == 1)
    {
        // if the number of digits right to the decimal point is biger on numStr1
        int rightToDot1 = size1 - valid1 - 1;
        int rightToDot2 = size2 - valid2 - 1;
        if (valid1 == valid2)
        {
            overHangL = 0;
        }
        if (valid1 > valid2)
        {
            if (rightToDot1 > rightToDot2)
            {
                overHangL = size1 - overHangR - size2;
            }
            if (rightToDot1 < rightToDot2)
            {
                overHangL = size1 + overHangR - size2;
            }
            if (rightToDot1 == rightToDot2)
            {
                overHangL = size1 - size2;
            }
        }
        if (valid2 > valid1)
        {
            if (rightToDot1 > rightToDot2)
            {
                overHangL = size2 + overHangR - size1;
            }
            if (rightToDot1 < rightToDot2)
            {
                overHangL = size2 - overHangR - size1;
            }
            if (rightToDot1 == rightToDot2)
            {
                overHangL = size2 - size1;
            }
        }
    }
    // computing overlap
    int overlap = -1;
    // no dots is the minimum string
    if (dot1 == -1 && dot2 == -1)
    {
        if (size1 >= size2)
        {
            overlap = size2;
        }
        else
        {
            overlap = size1;
        }
    }
    // if dot in numStr1 only
    if (dot1 == 1 && dot2 == -1)
    {
        if (size2 > size1)
        {
            overlap = size1 - overHangR;
        }
        // if minimal string is without dot
        if (size2 <= size1)
        {
            if (size1 - overHangR > size2)
            {
                overlap = size2;
            }
            else if (size1 - overHangR <= size2)
            {
                overlap = size1 - overHangR;
            }
        }
    }
    if (dot1 == -1 && dot2 == 1)
    {
        // if minimal string is with the dot
        if (size2 > size1)
        {
            if (size2 - overHangR > size1)
            {
                overlap = size2 - overHangR - overHangL;
            }
            else if (size2 - overHangR <= size1)
            {
                overlap = size2 - overHangR;
            }
        }
        // if minimal string is without dot
        if (size2 <= size1)
        {
            overlap = size2 - overHangR;
        }
    }
    // if dot in both (size1 + size2 - ovehangR - overhangL)/2
    if (dot1 == 1 && dot2 == 1)
    {
        int tempOver = overHangR + overHangL;
        int tempSize = size1 + size2;
        overlap = (tempSize - tempOver) / 2;
    }
    // computing the size of the the necessary sum to be inserted to buffer +1 for '\0'
    int expected = overHangL + overHangR + overlap + 1;
    char a1;
    char b1;
    // computing left most digit in overHangL is exsits, setting a1 and b1 to be last digist in overlap
    if (dot1 == 1 && dot2 == 1)
    {
        if (size1 > size2)
        {
            if (overHangL > 0)
            {
                // overHangL comes from numStr1
                if (size1 - overHangR > size2)
                {
                    a1 = numStr1[size1 - overHangR - overlap];
                    b1 = numStr2[0];
                    if ((numStr1[0] - '0') >= 9)
                    {
                        expected++;
                        expectedOverFlow = 1;
                    }
                }
                // overHangL comes from numStr2
                else if (size1 - overHangR < size2)
                {
                    a1 = numStr1[0];
                    b1 = numStr2[size2 - overlap];
                    char check = numStr2[0];
                    if ((check - '0') >= 9)
                    {
                        expected++;
                        expectedOverFlow = 1;
                    }
                }
            }
            else
            {
                a1 = numStr1[0];
                b1 = numStr2[0];
            }
        }
        if (size1 < size2)
        {
            if (overHangL > 0)
            {
                if (size2 - overHangR > size1)
                {
                    a1 = numStr1[0];
                    b1 = numStr2[size2 - overHangR - overlap];
                    if ((numStr2[0] - '0') >= 9)
                    {
                        expected++;
                        expectedOverFlow = 1;
                    }
                }

                else if (size2 - overHangR < size1)
                {
                    a1 = numStr1[size1 - overlap];
                    b1 = numStr2[0];
                    if ((numStr1[0] - '0') >= 9)
                    {
                        expected++;
                        expectedOverFlow = 1;
                    }
                }
            }
            else
            {
                a1 = numStr1[0];
                b1 = numStr2[0];
            }
        }
        if (size1 == size2)
        {
            a1 = numStr1[0];
            b1 = numStr2[0];
        }
    }

    if (dot1 == -1 && dot2 == -1)
    {
        if (size1 > size2)
        {
            a1 = numStr1[size1 - overlap];
            b1 = numStr2[0];
            if ((numStr1[0] - '0') >= 9)
            {
                expected++;
                expectedOverFlow = 1;
            }
        }
        if (size2 > size1)
        {
            a1 = numStr1[0];
            b1 = numStr2[size2 - overlap];
            if ((numStr2[0] - '0') >= 9)
            {
                expected++;
                expectedOverFlow = 1;
            }
        }
        else
        {
            a1 = numStr1[0];
            b1 = numStr2[0];
        }
    }
    // dot in numStr1 and not in NumStr2
    if (dot1 == 1 && dot2 == -1)
    {
        if (size1 > size2)
        {
            if (overHangL > 0)
            {
                if (size1 - overHangR > size2)
                {
                    a1 = numStr1[size1 - overHangR - overlap];
                    b1 = numStr2[0];
                    if ((numStr1[0] - '0') >= 9)
                    {
                        expected++;
                        expectedOverFlow = 1;
                    }
                }

                else if (size1 - overHangR < size2)
                {
                    a1 = numStr1[0];
                    b1 = numStr2[size2 - overlap];
                    if ((numStr2[0] - '0') >= 9)
                    {
                        expected++;
                        expectedOverFlow = 1;
                    }
                }
            }
            else
            {
                a1 = numStr1[0];
                b1 = numStr2[0];
            }
        }
        if (size1 <= size2)
        {
            a1 = numStr1[0];
            b1 = numStr2[size2 - overlap];
        }
    }
    // dot in numStr2 and not in NumStr1
    if (dot1 == -1 && dot2 == 1)
    {

        if (size1 > size2)
        {
            a1 = numStr1[size1 - overlap];
            b1 = numStr2[0];
            if ((numStr1[0] - '0') >= 9)
            {
                expected++;
                expectedOverFlow = 1;
            }
        }
        if (size1 <= size2)
        {
            if (overHangL > 0)
            {
                if (size2 - overHangR > size1)
                {
                    a1 = numStr1[0];
                    b1 = numStr2[size2 - overHangR - overlap];
                    if ((numStr2[0] - '0') >= 9)
                    {
                        expected++;
                        expectedOverFlow = 1;
                    }
                }

                else if (size2 - overHangR < size1)
                {
                    a1 = numStr1[size1 - overlap];
                    b1 = numStr2[0];
                    if ((numStr1[0] - '0') >= 9)
                    {
                        expected++;
                        expectedOverFlow = 1;
                    }
                }
            }
            else
            {
                a1 = numStr1[0];
                b1 = numStr2[0];
            }
        }
    }
    // if overHangL = 0 and a11 + b11 >=9 then increse expected
    int a11 = (a1 - '0');
    int b11 = (b1 - '0');
    if (a11 + b11 >= 9 && overHangL == 0)
    {
        expected++;
        expectedOverFlow = 1;
    }
    // is to large for the buffer space return - expected
    if (expected > buffSize)
    {
        return -expected;
    }
    // setting the closing char to the right place
    numStrSum[expected - 1] = '\0';
    // sum the string based on number of conditions : sizes, existence of dots, existence of overHangL and so on.
    if (dot1 == 1 && dot2 == -1)
    {
        const char *pointerA = &numStr1[0];
        const char *pointerB = &numStr2[0];
        char *pointerC = &numStrSum[0];
        int k = expected - 2;
        for (int i = size1 - 1; i >= size1 - overHangR; i--)
        {
            pointerC[k] = pointerA[i];
            k--;
        }
        if (size1 > size2)
        {
            if (overHangL > 0)
            {
                // overHangL comes from numStr1
                if (size1 - overHangR > size2)
                {
                    for (int j = size2 - 1; j >= 0; j--)
                    {
                        int digitSum = 0;
                        char a = pointerA[j - (size2 - 1) + size1 - 1];
                        char b = pointerB[j];
                        if (carry > 0)
                        {
                            digitSum = (a - '0') + (b - '0') + carry;
                            carry--;
                        }
                        else
                        {
                            digitSum = (a - '0') + (b - '0');
                        }
                        if (digitSum > 9)
                        {
                            digitSum = digitSum - 10;
                            carry++;
                        }
                        e = digitSum + '0';
                        pointerC[k] = e;
                        k--;
                    }
                    for (int j = overHangL - 1; j >= 0; j--)
                    {
                        int tempI = 0;
                        char temp = pointerA[j];
                        if (carry > 0)
                        {
                            tempI = (temp - '0') + carry;
                            carry--;
                        }
                        else
                        {
                            tempI = (temp - '0');
                        }
                        if (tempI > 9)
                        {
                            tempI = tempI - 10;
                            carry++;
                        }
                        temp = tempI + '0';
                        pointerC[k] = temp;
                        k--;
                    }
                }
                // overHangL comes from numStr2
                else if (size1 - overHangR < size2)
                {
                    for (int j = size1 - overHangR - 1; j >= 0; j--)
                    {
                        int digitSum = 0;
                        char a = pointerA[j];
                        char b = pointerB[j - (size1 - overHangR - 1) + size2 - 1];
                        if (carry > 0)
                        {
                            digitSum = (a - '0') + (b - '0') + carry;
                            carry--;
                        }
                        else
                        {
                            digitSum = (a - '0') + (b - '0');
                        }
                        if (digitSum > 9)
                        {
                            digitSum = digitSum - 10;
                            carry++;
                        }
                        e = digitSum + '0';
                        pointerC[k] = e;
                        k--;
                    }
                    //   0.004
                    // 201
                    for (int j = overHangL - 1; j >= 0; j--)
                    {
                        int tempI = 0;
                        char temp = pointerB[j];
                        if (carry > 0)
                        {
                            tempI = (temp - '0') + carry;
                            carry--;
                        }
                        else
                        {
                            tempI = (temp - '0');
                        }
                        if (tempI > 9)
                        {
                            tempI = tempI - 10;
                            carry++;
                        }
                        temp = tempI + '0';
                        pointerC[k] = temp;
                        k--;
                    }
                }
            }
            else
            {
                for (int j = size2 - 1; j >= 0; j--)
                {
                    int digitSum = 0;
                    char a = pointerA[j - (size2 - 1) + size1 - overHangR - 1];
                    char b = pointerB[j];
                    if (carry > 0)
                    {
                        digitSum = (a - '0') + (b - '0') + carry;
                        carry = 0;
                    }
                    else
                    {
                        digitSum = (a - '0') + (b - '0');
                    }
                    if (digitSum > 9)
                    {
                        digitSum = digitSum - 10;
                        carry++;
                    }
                    char e = digitSum + '0';
                    pointerC[k] = e;
                    k--;
                }
            }
        }
        if (size2 >= size1)
        {
            for (int j = size1 - 1 - overHangR; j >= 0; j--)
            {
                int digitSum = 0;
                char a = pointerA[j];
                char b = pointerB[j];
                if (carry > 0)
                {
                    digitSum = (a - '0') + (b - '0') + carry;
                    carry = 0;
                }
                else
                {
                    digitSum = (a - '0') + (b - '0');
                }
                if (digitSum > 9)
                {
                    digitSum = digitSum - 10;
                    carry++;
                }
                char e = digitSum + '0';
                pointerC[k] = e;
                k--;
            }
            for (int j = overHangL - 1; j >= 0; j--)
            {
                int tempI = 0;
                char temp = pointerB[j];
                if (carry > 0)
                {
                    tempI = (temp - '0') + carry;
                    carry--;
                }
                else
                {
                    tempI = (temp - '0');
                }
                if (tempI > 9)
                {
                    tempI = tempI - 10;
                    carry++;
                }
                temp = tempI + '0';
                pointerC[k] = temp;
                k--;
            }
        }
        // placeing the carry in the right place
        if (expectedOverFlow == 1)
        {
            numStrSum[0] = (carry + '0');
        }
        return 1;
    }
    // sum the string based on number of conditions : sizes, existence of dots, existence of overHangL and so on.
    if (dot1 == -1 && dot2 == 1)
    {
        const char *pointerA = &numStr1[0];
        const char *pointerB = &numStr2[0];
        char *pointerC = &numStrSum[0];
        int k = expected - 2;
        for (int i = size2 - 1; i >= size2 - overHangR; i--)
        {
            char t = pointerB[i];
            pointerC[k] = t;
            k--;
        }
        if (size1 >= size2)
        {
            for (int j = size2 - overHangR - 1; j >= 0; j--)
            {
                int digitSum = 0;
                char a = pointerA[j - (size2 - overHangR - 1) + size1 - 1];
                char b = pointerB[j];
                if (carry > 0)
                {
                    digitSum = (a - '0') + (b - '0') + carry;
                    carry = 0;
                }
                else
                {
                    digitSum = (a - '0') + (b - '0');
                }
                if (digitSum > 9)
                {
                    digitSum = digitSum - 10;
                    carry++;
                }
                char e = digitSum + '0';
                pointerC[k] = e;
                k--;
            }
            for (int j = overHangL - 1; j >= 0; j--)
            {
                int tempI = 0;
                char temp = pointerA[j];
                if (carry > 0)
                {
                    tempI = (temp - '0') + carry;
                    carry--;
                }
                else
                {
                    tempI = (temp - '0');
                }
                if (tempI > 9)
                {
                    tempI = tempI - 10;
                    carry++;
                }
                temp = tempI + '0';
                pointerC[k] = temp;
                k--;
            }
        }
        // size2 - overHangR > size1
        //  50
        // 201.004
        if (size2 > size1)
        {
            if (overHangL > 0)
            {
                if (size2 - overHangR > size1)
                {
                    for (int j = size2 - 1 - overHangR; j >= size2 - overHangR - overlap; j--)
                    {
                        int digitSum = 0;
                        char a = pointerA[j - (size2 - 1 - overHangR) + size1 - 1];
                        char b = pointerB[j];
                        if (carry > 0)
                        {
                            digitSum = (a - '0') + (b - '0') + carry;
                            carry = 0;
                        }
                        else
                        {
                            digitSum = (a - '0') + (b - '0');
                        }
                        if (digitSum > 9)
                        {
                            digitSum = digitSum - 10;
                            carry++;
                        }
                        char e = digitSum + '0';
                        pointerC[k] = e;
                        k--;
                    }
                    for (int j = overHangL -1; j >= 0; j--)
                    {
                        int tempI = 0;
                        char temp = pointerB[j];
                        if (carry > 0)
                        {
                            tempI = (temp - '0') + carry;
                            carry--;
                        }
                        else
                        {
                            tempI = (temp - '0');
                        }
                        if (tempI > 9)
                        {
                            tempI = tempI - 10;
                            carry++;
                        }
                        temp = tempI + '0';
                        pointerC[k] = temp;
                        k--;
                    }
                }
                //size2 - overHangR < size1
                else if (size2 - overHangR < size1)
                {
                    for (int j = size2 - overHangR - 1; j >= 0; j--)
                    {
                        int digitSum = 0;
                        char a = pointerA[j - (size2 - overHangR - 1) + size1 - 1];
                        char b = pointerB[j];
                        if (carry > 0)
                        {
                            digitSum = (a - '0') + (b - '0') + carry;
                            carry = 0;
                        }
                        else
                        {
                            digitSum = (a - '0') + (b - '0');
                        }
                        if (digitSum > 9)
                        {
                            digitSum = digitSum - 10;
                            carry++;
                        }
                        char e = digitSum + '0';
                        pointerC[k] = e;
                        k--;
                    }
                    for (int j = overHangL - 1; j >= 0; j--)
                    {
                        int tempI = 0;
                        char temp = pointerA[j];
                        if (carry > 0)
                        {
                            tempI = (temp - '0') + carry;
                            carry--;
                        }
                        else
                        {
                            tempI = (temp - '0');
                        }
                        if (tempI > 9)
                        {
                            tempI = tempI - 10;
                            carry++;
                        }
                        temp = tempI + '0';
                        pointerC[k] = temp;
                        k--;
                    }
                }
            }
            else
            {
                for (int j = size2 - overHangR - 1; j >= 0; j--)
                {
                    int digitSum = 0;
                    char a = pointerA[j - (size2 - overHangR - 1) + size1 - 1];
                    char b = pointerB[j];
                    if (carry > 0)
                    {
                        digitSum = (a - '0') + (b - '0') + carry;
                        carry = 0;
                    }
                    else
                    {
                        digitSum = (a - '0') + (b - '0');
                    }
                    if (digitSum > 9)
                    {
                        digitSum = digitSum - 10;
                        carry++;
                    }
                    char e = digitSum + '0';
                    pointerC[k] = e;
                    k--;
                }
            }
        }
        // placeing the carry in the right place
        if (expectedOverFlow == 1)
        {
            numStrSum[0] = (carry + '0');
        }
        return 1;
    }
    // sum the string based on number of conditions : sizes, existence of dots, existence of overHangL and so on.
    if (dot1 == -1 && dot2 == -1)
    {
        const char *pointerA = &numStr1[0];
        const char *pointerB = &numStr2[0];
        char *pointerC = &numStrSum[0];
        int k = expected - 2;
        // if both string are of the same size.
        if (size1 == size2)
        {
            for (int j = size1 - 1; j >= 0; j--)
            {
                int digitSum = 0;
                char a = pointerA[j];
                char b = pointerB[j];
                if (carry > 0)
                {
                    digitSum = (a - '0') + (b - '0') + carry;
                    carry = 0;
                }
                else
                {
                    digitSum = (a - '0') + (b - '0');
                }
                if (digitSum > 9)
                {
                    digitSum = digitSum - 10;
                    carry++;
                }
                char e = digitSum + '0';
                pointerC[k] = e;
                k--;
            }
        }
        // 97
        //  9\0
        // sumnig the digits from location 0 until the samllar string , then just adding the reminder from the big one.
        if (size1 > size2)
        {
            for (int j = size1 - 1; j >= size1 - size2; j--)
            {
                int digitSum = 0;
                char a = pointerA[j];
                char b = pointerB[j - (size1 - 1) + size2 - 1];
                if (carry > 0)
                {
                    digitSum = (a - '0') + (b - '0') + carry;
                    carry = 0;
                }
                else
                {
                    digitSum = (a - '0') + (b - '0');
                }
                if (digitSum > 9)
                {
                    digitSum = digitSum - 10;
                    carry++;
                }
                char e = digitSum + '0';
                pointerC[k] = e;
                k--;
            }
            for (int j = overHangL - 1; j >= 0; j--)
            {
                int tempI = 0;
                char temp = pointerA[j];
                if (carry > 0)
                {
                    tempI = (temp - '0') + carry;
                    carry--;
                }
                else
                {
                    tempI = (temp - '0');
                }
                if (tempI > 9)
                {
                    tempI = tempI - 10;
                    carry++;
                }
                temp = tempI + '0';
                pointerC[k] = temp;
                k--;
            }
        }

        // sumnig the digits from location 0 until the samllar string , then just adding the reminder from the big one.
        if (size2 > size1)
        {
            for (int j = size2 - 1; j >= size2 - size1; j--)
            {
                int digitSum = 0;
                char a = pointerA[j - (size2 - 1) + size1 - 1];
                char b = pointerB[j];
                if (carry > 0)
                {
                    digitSum = (a - '0') + (b - '0') + carry;
                    carry = 0;
                }
                else
                {
                    digitSum = (a - '0') + (b - '0');
                }
                if (digitSum > 9)
                {
                    digitSum = digitSum - 10;
                    carry++;
                }
                char e = digitSum + '0';
                pointerC[k] = e;
                k--;
            }
            for (int j = overHangL - 1; j >= 0; j--)
            {
                int tempI = 0;
                char temp = pointerB[j];
                if (carry > 0)
                {
                    tempI = (temp - '0') + carry;
                    carry--;
                }
                else
                {
                    tempI = (temp - '0');
                }
                if (tempI > 9)
                {
                    tempI = tempI - 10;
                    carry++;
                }
                temp = tempI + '0';
                pointerC[k] = temp;
                k--;
            }
        }
        // placeing the carry in the right place
        if (expectedOverFlow == 1)
        {
            numStrSum[0] = (carry + '0');
        }
        return 1;
    }
    // sum the string based on number of conditions : sizes, existence of dots, existence of overHangL and so on.
    if (dot1 == 1 && dot2 == 1)
    {
        const char *pointerA = &numStr1[0];
        const char *pointerB = &numStr2[0];
        char *pointerC = &numStrSum[0];
        int k = expected - 2;
        if (size1 > size2)
        {
            if (overHangR > 0)
            {
                if (afterdot1 > afterdot2)
                {
                    for (int i = size1 - 1; i >= size1 - overHangR; i--)
                    {
                        char t = pointerA[i];
                        pointerC[k] = t;
                        k--;
                    }
                    for (int j = size1 - 1 - overHangR; j >= size1 - overHangR - overlap; j--)
                    {
                        int digitSum = 0;
                        char a = pointerA[j];
                        char b = pointerB[j - (size1 - overHangR - 1) + size2 - 1];
                        if (carry > 0)
                        {
                            if (a != '.')
                            {
                                digitSum = (a - '0') + (b - '0') + carry;
                                carry--;
                            }
                            else
                            {
                                digitSum = 92;
                            }
                        }
                        else
                        {
                            if (a != '.')
                            {
                                digitSum = (a - '0') + (b - '0');
                            }
                            else
                            {
                                digitSum = 92;
                            }
                        }
                        if (digitSum > 9 && digitSum != 92)
                        {
                            digitSum = digitSum - 10;
                            carry++;
                        }
                        if (digitSum != 92)
                        {
                            e = digitSum + '0';
                            pointerC[k] = e;
                        }
                        else
                        {
                            e = '.';
                            pointerC[k] = e;
                        }
                        k--;
                    }
                    if (overHangL > 0)
                    {
                        // if overHangL is from numStr1
                        if (size1 - overHangR > size2)
                        {
                            for (int j = overHangL - 1; j >= 0; j--)
                            {
                                int tempI = 0;
                                char temp = pointerA[j];
                                if (carry > 0)
                                {
                                    tempI = (temp - '0') + carry;
                                    carry--;
                                }
                                else
                                {
                                    tempI = (temp - '0');
                                }
                                if (tempI > 9)
                                {
                                    tempI = tempI - 10;
                                    carry++;
                                }
                                temp = tempI + '0';
                                pointerC[k] = temp;
                                k--;
                            }
                        }
                        // if overHangL is from numStr2
                        else if (size1 - overHangR < size2)
                        {
                            for (int j = overHangL - 1; j >= 0; j--)
                            {
                                int tempI = 0;
                                char temp = pointerB[j];
                                if (carry > 0)
                                {
                                    tempI = (temp - '0') + carry;
                                    carry--;
                                }
                                else
                                {
                                    tempI = (temp - '0');
                                }
                                if (tempI > 9)
                                {
                                    tempI = tempI - 10;
                                    carry++;
                                }
                                temp = tempI + '0';
                                pointerC[k] = temp;
                                k--;
                            }
                        }
                    }
                }
                if (afterdot1 < afterdot2)
                {
                    for (int i = size2 - 1; i >= size2 - overHangR; i--)
                    {
                        pointerC[k] = pointerB[i];
                        k--;
                    }
                    for (int j = size2 - 1 - overHangR; j >= size2 - overHangR - overlap; j--)
                    {
                        int digitSum = 0;
                        char a = pointerA[j - (size2 - 1 - overHangR) + size1 - 1];
                        char b = pointerB[j];
                        if (carry > 0)
                        {
                            if (a != '.')
                            {
                                digitSum = (a - '0') + (b - '0') + carry;
                                carry--;
                            }
                            else
                            {
                                digitSum = 92;
                            }
                        }
                        else
                        {
                            if (a != '.')
                            {
                                digitSum = (a - '0') + (b - '0');
                            }
                            else
                            {
                                digitSum = 92;
                            }
                        }
                        if (digitSum > 9 && digitSum != 92)
                        {
                            digitSum = digitSum - 10;
                            carry++;
                        }
                        if (digitSum != 92)
                        {
                            e = digitSum + '0';
                            pointerC[k] = e;
                        }
                        else
                        {
                            e = '.';
                            pointerC[k] = e;
                        }
                        k--;
                    }
                    if (overHangL > 0)
                    {
                        for (int j = overHangL - 1; j >= 0; j--)
                        {
                            int tempI = 0;
                            char temp = pointerA[j];
                            if (carry > 0)
                            {
                                tempI = (temp - '0') + carry;
                                carry--;
                            }
                            else
                            {
                                tempI = (temp - '0');
                            }
                            if (tempI > 9)
                            {
                                tempI = tempI - 10;
                                carry++;
                            }
                            temp = tempI + '0';
                            pointerC[k] = temp;
                            k--;
                        }
                    }
                }
            }
            else
            {
                for (int j = size2 - 1; j >= 0; j--)
                {
                    int digitSum = 0;
                    char a = pointerA[j];
                    char b = pointerB[j];
                    if (carry > 0)
                    {
                        if (a != '.')
                        {
                            digitSum = (a - '0') + (b - '0') + carry;
                            carry--;
                        }
                        else
                        {
                            digitSum = 92;
                        }
                    }
                    else
                    {
                        if (a != '.')
                        {
                            digitSum = (a - '0') + (b - '0');
                        }
                        else
                        {
                            digitSum = 92;
                        }
                    }
                    if (digitSum > 9 && digitSum != 92)
                    {
                        digitSum = digitSum - 10;
                        carry++;
                    }
                    if (digitSum != 92)
                    {
                        e = digitSum + '0';
                        pointerC[k] = e;
                    }
                    else
                    {
                        e = '.';
                        pointerC[k] = e;
                    }
                    k--;
                }
                for (int j = overHangL - 1; j >= 0; j--)
                {
                    int tempI = 0;
                    char temp = pointerA[j];
                    if (carry > 0)
                    {
                        tempI = (temp - '0') + carry;
                        carry--;
                    }
                    else
                    {
                        tempI = (temp - '0');
                    }
                    if (tempI > 9)
                    {
                        tempI = tempI - 10;
                        carry++;
                    }
                    temp = tempI + '0';
                    pointerC[k] = temp;
                    k--;
                }
            }
        }
        if (size1 < size2)
        {
            if (overHangR > 0)
            {
                if (afterdot1 > afterdot2)
                {
                    for (int i = size1 - 1; i >= size1 - overHangR; i--)
                    {
                        pointerC[k] = pointerA[i];
                        k--;
                    }
                    for (int j = size1 - 1 - overHangR; j >= size1 - overHangR - overlap; j--)
                    {
                        int digitSum = 0;
                        char a = pointerA[j];
                        char b = pointerB[j - (size1 - 1 - overHangR) + size2 - 1];
                        if (carry > 0)
                        {
                            if (a != '.')
                            {
                                digitSum = (a - '0') + (b - '0') + carry;
                                carry--;
                            }
                            else
                            {
                                digitSum = 92;
                            }
                        }
                        else
                        {
                            if (a != '.')
                            {
                                digitSum = (a - '0') + (b - '0');
                            }
                            else
                            {
                                digitSum = 92;
                            }
                        }
                        if (digitSum > 9 && digitSum != 92)
                        {
                            digitSum = digitSum - 10;
                            carry++;
                        }
                        if (digitSum != 92)
                        {
                            e = digitSum + '0';
                            pointerC[k] = e;
                        }
                        else
                        {
                            e = '.';
                            pointerC[k] = e;
                        }
                        k--;
                    }
                    for (int j = overHangL - 1; j >= 0; j--)
                    {
                        int tempI = 0;
                        char temp = pointerB[j];
                        if (carry > 0)
                        {
                            tempI = (temp - '0') + carry;
                            carry--;
                        }
                        else
                        {
                            tempI = (temp - '0');
                        }
                        if (tempI > 9)
                        {
                            tempI = tempI - 10;
                            carry++;
                        }
                        temp = tempI + '0';
                        pointerC[k] = temp;
                        k--;
                    }
                }
                if (afterdot1 < afterdot2)
                {
                    for (int i = size2 - 1; i >= size2 - overHangR; i--)
                    {
                        char s = pointerB[i];
                        pointerC[k] = s;
                        k--;
                    }
                    for (int j = size2 - 1 - overHangR; j >= 0; j--)
                    {
                        int digitSum = 0;
                        char a = pointerA[j - (size2 - 1 - overHangR) + size1 - 1];
                        char b = pointerB[j];
                        if (carry > 0)
                        {
                            if (a != '.')
                            {
                                digitSum = (a - '0') + (b - '0') + carry;
                                carry = 0;
                            }
                            else
                            {
                                digitSum = 92;
                            }
                        }
                        else
                        {
                            if (a != '.')
                            {
                                digitSum = (a - '0') + (b - '0');
                            }
                            else
                            {
                                digitSum = 92;
                            }
                        }
                        if (digitSum > 9 && digitSum != 92)
                        {
                            digitSum = digitSum - 10;
                            carry++;
                        }
                        if (digitSum != 92)
                        {
                            e = digitSum + '0';
                            pointerC[k] = e;
                        }
                        else
                        {
                            e = '.';
                            pointerC[k] = e;
                        }
                        k--;
                    }
                    if (overHangL > 0)
                    {
                        // OverHangL comes from numStr2
                        if (size2 - overHangR > size1)
                        {
                            for (int j = overHangL - 1; j >= 0; j--)
                            {
                                int tempI = 0;
                                char temp = pointerB[j];
                                if (carry > 0)
                                {
                                    tempI = (temp - '0') + carry;
                                    carry--;
                                }
                                else
                                {
                                    tempI = (temp - '0');
                                }
                                if (tempI > 9)
                                {
                                    tempI = tempI - 10;
                                    carry++;
                                }
                                temp = tempI + '0';
                                pointerC[k] = temp;
                                k--;
                            }
                        }
                        // OverHangL comes from numStr1
                        if (size2 - overHangR < size1)
                        {
                            for (int j = overHangL - 1; j >= 0; j--)
                            {
                                int tempI = 0;
                                char temp = pointerA[j];
                                if (carry > 0)
                                {
                                    tempI = (temp - '0') + carry;
                                    carry--;
                                }
                                else
                                {
                                    tempI = (temp - '0');
                                }
                                if (tempI > 9)
                                {
                                    tempI = tempI - 10;
                                    carry++;
                                }
                                temp = tempI + '0';
                                pointerC[k] = temp;
                                k--;
                            }
                        }
                    }
                }
            }
            else
            {
                for (int j = size1 - 1; j >= 0; j--)
                {
                    int digitSum = 0;
                    char a = pointerA[j];
                    char b = pointerB[j + overHangL];
                    if (carry > 0)
                    {
                        if (a != '.')
                        {
                            digitSum = (a - '0') + (b - '0') + carry;
                            carry--;
                        }
                        else
                        {
                            digitSum = 92;
                        }
                    }
                    else
                    {
                        if (a != '.')
                        {
                            digitSum = (a - '0') + (b - '0');
                        }
                        else
                        {
                            digitSum = 92;
                        }
                    }
                    if (digitSum > 9 && digitSum != 92)
                    {
                        digitSum = digitSum - 10;
                        carry++;
                    }
                    if (digitSum != 92)
                    {
                        e = digitSum + '0';
                        pointerC[k] = e;
                    }
                    else
                    {
                        e = '.';
                        pointerC[k] = e;
                    }
                    k--;
                }
                for (int j = overHangL - 1; j >= 0; j--)
                {
                    int tempI = 0;
                    char temp = pointerB[j];
                    if (carry > 0)
                    {
                        tempI = (temp - '0') + carry;
                        carry--;
                    }
                    else
                    {
                        tempI = (temp - '0');
                    }
                    if (tempI > 9)
                    {
                        tempI = tempI - 10;
                        carry++;
                    }
                    temp = tempI + '0';
                    pointerC[k] = temp;
                    k--;
                }
            }
        }
        if (size1 == size2)
        {
            for (int j = size2 - 1; j >= 0; j--)
            {
                int digitSum = 0;
                char a = pointerA[j];
                char b = pointerB[j];
                if (carry > 0)
                {
                    if (a != '.')
                    {
                        digitSum = (a - '0') + (b - '0') + carry;
                        carry--;
                    }
                    else
                    {
                        digitSum = 92;
                    }
                }
                else
                {
                    if (a != '.')
                    {
                        digitSum = (a - '0') + (b - '0');
                    }
                    else
                    {
                        digitSum = 92;
                    }
                }
                if (digitSum > 9 && digitSum != 92)
                {
                    digitSum = digitSum - 10;
                    carry++;
                }
                if (digitSum != 92)
                {
                    e = digitSum + '0';
                    pointerC[k] = e;
                }
                else
                {
                    e = '.';
                    pointerC[k] = e;
                }
                k--;
            }
        }
        // placeing the carry in the right place
        if (expectedOverFlow == 1)
        {
            char temp = (carry + '0');
            numStrSum[0] = temp;
        }
        return 1;
    }
    // return never to be reached (compailer demand...)
    return 10;
}
int standardizeNumString(char *numStr)
{
    int size = strlen(numStr);
    int lead = numLeadingZeros(numStr);
    int trail = numTrailingZeros(numStr);
    int valid = decimalPointPosition(numStr);
    // is valid?
    if (valid == -1)
    {
        return 0;
    }
    // is there a dot in the string?
    int dot = -1;
    char c;
    for (int i = 0; i < size; i++)
    {
        c = numStr[i];
        if (c == '.')
        {
            dot = 1;
        }
    }
    // is integer with dot?
    int integer = -1;
    if (dot != -1 && valid == size - trail - 1)
    {
        integer = 1;
    }
    // is standart form and integer already?
    if (dot == -1)
    {
        if (lead == 0 && trail == 0)
        {
            return 1;
        }
    }
    // is standart form and double already?
    if (dot == 1)
    {
        if (lead == 0 && trail == 0)
        {
            return 1;
        }
    }
    // modification is needed.
    for (int i = 0; i + lead < size - trail; i++)
    {
        numStr[i] = numStr[i + lead];
    }
    //integer with dot in the end.
    if (integer == 1)
    {
        numStr[size - trail - lead - 1] = '\0';
    }
    else
    {
        numStr[size - trail - lead] = '\0';
    }
    return 0;
}
double numStringToDouble(const char *numStr)
{
    int size = strlen(numStr);
    int lead = numLeadingZeros(numStr);
    int trail = numTrailingZeros(numStr);
    double num = 0;
    int valid = decimalPointPosition(numStr);
    if (valid == -1)
    {
        return -1;
    }
    char c;
    double afterDot = 0;
    int index = 0;
    char t;
    int counter = 0;
    for (int i = lead; i < (size - trail); i++)
    {
        c = numStr[i];
        if (c != '.')
        {
            num = num * 10 + (c - '0');
        }
        else
        {
            index = i;
            break;
        }
    }
    if (index != 0)
    {
        double divider = 10;
        for (int j = index + 1; j < (size - trail); j++)
        {
            t = numStr[j];
            afterDot = afterDot * 10 + (t - '0');
            counter++;
        }

        //printf("%d\n", counter);
        int min = -1;
        if (counter - 1 <= 16 - decimalPointPosition(numStr))
        {
            min = counter - 1;
        }
        else
        {
            min = 16 - decimalPointPosition(numStr);
        }
        for (int k = 0; k < min; k++)
        {
            divider = divider * 10;
        }
        printf("%lf\n", divider);
        afterDot = afterDot / divider;
    }
    return (num + afterDot);
}
int numStringIsInteger(const char *numStr)
{
    int decPos = decimalPointPosition(numStr);
    return (decPos + numTrailingZeros(numStr) == (strlen(numStr)) || (decPos + numTrailingZeros(numStr) + 1) == (strlen(numStr)));
}
int numTrailingZeros(const char *numStr)
{
    int size = strlen(numStr);
    int valid = decimalPointPosition(numStr);
    if (valid == -1)
    {
        return -1;
    }
    int dot;
    if (valid == size)
    {
        dot = -1;
    }

    if (numStr[size - 1] != '0')
    {
        return 0;
    }
    char c;
    int counter = 0;
    int i = size - 1;
    while (i >= 0)
    {
        c = numStr[i];
        if (c != '0')
        {
            break;
        }
        counter++;
        i--;
    }
    if (dot == -1)
    {
        return 0;
    }
    return counter;
}
int numLeadingZeros(const char *numStr)
{
    int size = strlen(numStr);
    int valid = decimalPointPosition(numStr);
    if (valid == -1)
    {
        return -1;
    }
    int dot;
    if (valid == size)
    {
        dot = -1;
    }

    if (numStr[0] != '0')
    {
        return 0;
    }
    char c;
    int counter = 0;
    int i = 0;
    int zeroCounter = 0;
    while (i < size)
    {
        c = numStr[i];
        if (c != '0')
        {
            if (c == '.')
            {
                counter--;
            }
            break;
        }
        zeroCounter++;
        counter++;
        i++;
    }
    // if the number is only zeros and there is no dot
    if (dot == -1 && zeroCounter == size)
    {
        counter--;
    }
    return counter;
}
int decimalPointPosition(const char *numStr)
{
    int size = strlen(numStr);
    if (size == 0)
    {
        return -1;
    }
    if (numStr[0] == 46)
    {
        return -1;
    }
    int dot = 0;
    int dotIndex = 0;
    for (int i = 0; i < size; i++)
    {
        char c = numStr[i];
        if (((c < '0') && (c != '.')) || (c > '9'))
        {
            return -1;
        }
        if (c == '.')
        {
            dot++;
            dotIndex = i;
        }
    }
    if (dot > 1)
    {
        return -1;
    }
    if (dot == 0)
    {
        return size;
    }
    return dotIndex;
}
