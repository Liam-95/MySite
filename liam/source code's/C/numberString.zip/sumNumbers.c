#include <stdio.h>
#include <string.h>
#include "numberString.c"
#include <stdlib.h>
// --filename--
int main(int argc, char **argv)
{
    if (argc <= 1)
    {
        printf("The sum of the 0 input numbers is 0");
        return 0;
    }
    int counterInValid = 0;
    int counterValid = 0;
    char temp[10];
    char *ptr;
    int i = 1;
    int j = 1;
    char *current = argv[i];
    char *next = argv[j];
    while (decimalPointPosition(current) == -1 && i < argc)
    {
        counterInValid++;
        i++;
        if (i <= argc - 1)
        {
            current = argv[i];
        }
    }
    // check if the while of i stoped beacuse we found valid string
    if (i + 1 < argc)
    {
        j = i + 1;
    }
    // chack if argv[i] valid or not
    else if (i + 1 >= argc)
    {
        // if argv[i] valid thus there exsits only one valid string at index argc-1
        if (i == argc)
        {
            i--;
        }
        if (decimalPointPosition(argv[i]) != -1)
        {
            counterValid++;
            ptr = argv[i];
            standardizeNumString(ptr);
            printf("The sum of the "
                   "%d",
                   counterValid);
            printf(" input numbers is "
                   "%s",
                   ptr);
            return counterInValid;
        }
        // all arguments are invalid
        else
        {
            printf("The sum of the 0 input numbers is 0");
            return counterInValid;
        }
    }
    next = argv[j];
    while (decimalPointPosition(next) == -1 && j < argc)
    {
        counterInValid++;
        j++;
        // j after increment is not aout of bound
        if (j <= argc - 1)
        {
            next = argv[j];
        }
    }
    // i is valid. chack if while stoped beacsue j valid or j last index
    if (j >= argc - 1)
    {
        if (j == argc)
        {
            j--;
        }
        if (decimalPointPosition(argv[j]) == -1)
        {
            counterValid++;
            ptr = argv[i];
            standardizeNumString(ptr);
            printf("The sum of the "
                   "%d",
                   counterValid);
            printf(" input numbers is "
                   "%s",
                   ptr);
            return counterInValid;
        }
    }
    next = argv[j];
    // there exsits at least 2 valid inputs
    counterValid = counterValid + 2;
    standardizeNumString(current);
    standardizeNumString(next);
    int size = (-1 * numStringSum(current, next, temp, 0));
    ptr = (char *)malloc(size * sizeof(char));
    if (!ptr)
    {
        return -1;
    }
    numStringSum(current, next, ptr, size);
    standardizeNumString(ptr);

    j++;
    for (; j < argc; j++)
    {
        current = argv[j];
        int validCurrent = decimalPointPosition(current);
        if (validCurrent == -1)
        {
            counterInValid++;
            continue;
        }
        else
        {
            counterValid++;
            standardizeNumString(current);
            int size = (-1 * numStringSum(current, ptr, temp, 0));
            char *oldPtr = ptr;
            ptr = (char *)malloc(size * sizeof(char));
            if (!ptr)
            {
                return -1;
            }
            numStringSum(current, oldPtr, ptr, size);
            standardizeNumString(ptr);
            free(oldPtr);
        }
    }
    printf("The sum of the "
           "%d",
           counterValid);
    printf(" input numbers is "
           "%s",
           ptr);
    return counterInValid;
}