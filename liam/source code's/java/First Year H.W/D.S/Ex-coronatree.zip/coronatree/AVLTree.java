package coronatree;

public class AVLTree {

    AVLNode root; // The tree root.
    int size; // The size of the tree.

    /**
     * Construct an empty tree.
     */
    public AVLTree() {
        this.root = null;
        this.size = 0;
    }

    /**
     * Returns the size of the tree.
     * 
     * @return the size of the tree.
     */
    public int size() {
        return this.size;
    }

    /**
     * Returns the height of the tree. Returns -1 if the tree is empty.
     * 
     * @return the height of the tree.
     */
    public int height() {
        return this.root.height;
    }

    // compute balance
    private int getBalance(AVLNode current) {
        if (current == null) {
            return 0;
        } else {
            return getHeight(current.right) - getHeight(current.left);
        }
    }

    // get height
    private int getHeight(AVLNode current) {
        if (current == null) {
            return -1;
        } else {
            return current.height;
        }
    }

    // update height
    private void updateHeight(AVLNode current) {
        current.height = Math.max(getHeight(current.left), getHeight(current.right)) + 1;
    }

    /**
     * Inserts into the tree; You may assume that every person has a unique ID
     * number. That is, no person will appear twice.
     * 
     * @param p - the person to insert.
     */
    public void insert(Person p) {
        this.root = insertReal(root,p);
    }

    private AVLNode insertReal(AVLNode current, Person p) {
        if (current == null) {
            current = new AVLNode(p);
            size++;
            return current;
        }
        if (p.id < current.data.id) {
            current.left = insertReal(current.left, p);
            current.left.parent = current;
        } else if (p.id > current.data.id) {
            current.right = insertReal(current.right, p);
            current.right.parent = current;
        }
        int balance = getBalance(current);
        // RotateLeft2Right
        if (balance < -1 && p.id < current.left.data.id) {
            return RotateLeft2Right(current);
        }
        // DoubleRotateLeft2Right
        else if (balance < -1 && p.id > current.left.data.id) {
            return DoubleRotateLeft2Right(current);
        }
        // RotateRight2Left
        else if (balance > 1 && p.id > current.right.data.id) {
            return RotateRight2Left(current);
        }
        // DoubleRotateRight2Left
        else if (balance > 1 && p.id < current.right.data.id) {
            return DoubleRotateRight2Left(current);
        }
        // no rotation needed, update height.
        else {
            updateHeight(current);
            return current;
        }
    }
    // RotateLeft2Right
    private AVLNode RotateLeft2Right(AVLNode y) {
        AVLNode x = y.left;
        AVLNode t23 = x.right;
        y.left = t23;
        if (t23 != null && t23.parent != null) {
            t23.parent = y;
        }
        x.parent = y.parent;
        if (y.parent != null && y.parent.left == y) {
            y.parent.left = x;
        }
        if (y.parent != null && y.parent.right == y) {
            y.parent.right = x;
        }
        x.right = y;
        y.parent = x;
        updateHeight(y);
        updateHeight(x);
        return x;
    }

    // rotate RotateRight2Left then rotate RotateLeft2Right
    private AVLNode DoubleRotateLeft2Right(AVLNode current) {
        current.left = RotateRight2Left(current.left);
        return RotateLeft2Right(current);
    }

    // rotate from right to left
    private AVLNode RotateRight2Left(AVLNode x) {
        AVLNode z = x.right;
        AVLNode t23 = z.left;
        // rotation
        x.right = t23;
        if (t23 != null && t23.parent != null) {
            t23.parent = x;
        }
        z.parent = x.parent;
        // update parent
        if (x.parent != null && x.parent.left == x) {
            x.parent.left = z;
        }
        if (x.parent != null && x.parent.right == x) {
            x.parent.right = z;
        }
        z.left = x;
        x.parent = z;
        updateHeight(x);
        updateHeight(z);
        return z;
    }

    // rotate RotateLeft2Right then rotate RotateRight2Left
    private AVLNode DoubleRotateRight2Left(AVLNode current) {
        current.right = RotateLeft2Right(current.right);
        return RotateRight2Left(current);
    }

    /**
     * Search for a person in the tree.
     * 
     * @param p the person to search for.
     * @return true iff 'p' is an element in the tree.
     */
    public boolean search(Person p) {
        AVLNode current = this.root;
        while (current != null) {
            if (current.data.id == p.id) {
                return true;
            }
            if (current.data.id < p.id) {
                current = current.right;
            } else {
                current = current.left;
            }
        }
        return false;
    }

    /**
     * Traverse the contents of this tree in an 'inorder' manner and return and
     * array containing the traversal of the tree.
     * 
     * @return a sorted array of the tree's content.
     */
    public Person[] inorder() {
        Person[] ans = new Person[size];
        int pos = 0;
        inorderReal(root, ans, pos);
        return ans;
    }

    private int inorderReal(AVLNode root, Person[] ans, int pos) {
        if (root.left != null) {
            pos = inorderReal(root.left, ans, pos);
        }
        ans[pos++] = root.data;
        if (root.right != null) {
            pos = inorderReal(root.right, ans, pos);
        }
        return pos; // return the last position filled in by this invocation
    }

}
