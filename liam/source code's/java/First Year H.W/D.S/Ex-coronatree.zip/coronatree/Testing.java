package coronatree;

public class Testing {

	public static void main(String[] args) {
		AVLTree rec = new AVLTree();
    	Person a = new Person(1, "Aaron");
    	Person b = new Person(2, "Baron");
    	Person c = new Person(3, "Cauron");
    	Person d = new Person(4, "Dareon");
    	Person e = new Person(5, "Eve");
    	Person f = new Person(6, "Frenkel");
    	Person g = new Person(7, "Gorge");
    	Person h = new Person(8, "Hana");
    	Person i = new Person(9, "Iori");
    	Person j = new Person(10, "Juv");
    	
    	rec.insert(c);
    	rec.insert(d);
    	rec.insert(e);
    	rec.insert(i);
    	rec.insert(f);
    	rec.insert(a);
    	rec.insert(b);
    	rec.insert(g);
    	rec.insert(h);
    	rec.insert(j);
    	/*
    	System.out.println("root : " + rec.root);
    	System.out.println("root.left : " +rec.root.left);
    	System.out.println("root.right : " +rec.root.right);
    	System.out.println("root.left.left : " +rec.root.left.left);
    	System.out.println("root.left.right : " +rec.root.left.right);
    	System.out.println("root.right.left : " +rec.root.right.left);
    	System.out.println("root.right.right : " +rec.root.right.right);
    	*/
    	Person[] wait = rec.inorder();
        	for (Person p: wait) {
    			System.out.println(p + "; ");
    		}
        	System.out.println();
        System.out.println(rec.size);
        System.out.println(rec.root);
       System.out.println(rec.root.left);
        System.out.println(rec.root.right);
        System.out.println(rec.root.right.right);
        System.out.println(rec.height());
        System.out.println();
        
    	printTree(rec);

	}
	
	public static void printTree(AVLTree tree) {
		System.out.printf("%100s %n", tree.root);
		System.out.printf("%70s %60s %n", tree.root.left, tree.root.right);
		System.out.printf("%50s %30s %30s %30s %n", tree.root.left.left, tree.root.left.right,tree.root.right.left, tree.root.right.right);
		System.out.printf("%20s %20s %20s %20s %20s %20s %20s %20s %n", tree.root.left.left.left, tree.root.left.left.right,tree.root.left.right.left,tree.root.left.right.right,tree.root.right.left.left,tree.root.right.left.right,tree.root.right.right.left,tree.root.right.right.right);
		System.out.println(tree.root.right.right.right.right);
	}

}
