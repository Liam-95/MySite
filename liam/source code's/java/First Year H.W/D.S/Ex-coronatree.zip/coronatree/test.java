// package coronatree;

// /**
//  * test
//  */
// public class test {
//     public static void main(String[] args) {
//         // VaccinationRecords rec = new VaccinationRecords();
//         Person a = new Person(1, "Aaron");
//         Person b = new Person(2, "Baron");
//         Person c = new Person(3, "Cauron");
//         Person d = new Person(4, "Dareon");
//         Person e = new Person(6, "eareon");
//         Person f = new Person(5, "fareon");
//         Person g = new Person(20, "gareon");
//         Person h = new Person(13, "hareon");
//         Person i = new Person(99, "iareon");
//         AVLTree kl = new AVLTree();
//         kl.insert(i);
//         kl.insert(a);
//         kl.insert(e);
//         kl.insert(c);
//         kl.insert(g);
//         kl.insert(d);
//         kl.insert(f);
//         kl.insert(b);
//         kl.insert(h);
//         rec.insert(a);
//         rec.insert(d);
//         Person[] wait = rec.listNonVaccinatedSubjects();
//         for (Person p : wait) {
//         System.out.print(p + "; ");
//         System.out.println();
//         System.out.println(rec.checkVaccinated(a));
//         System.out.println(rec.checkVaccinated(b));
//         rec.vaccinateSubjects();
//         rec.insert(b);
//         rec.insert(c);
//         wait = rec.listNonVaccinatedSubjects();
//         for (Person p : wait) {
//         System.out.print(p + "; ");
//         }
//         System.out.println();
//         Person[] vacc = rec.listVaccinatedSubjects();
//         for (Person p : vacc) {
//         System.out.print(p + "; ");
//         }
//         System.out.println();
//         System.out.println(rec.checkVaccinated(a));
//         System.out.println(rec.checkVaccinated(b));
//         rec.vaccinateSubjects();
//         vacc = rec.listVaccinatedSubjects();
//         for (Person p : vacc) {
//         System.out.print(p + "; ");
//         }
//         System.out.println();
//         System.out.println(rec.T2.height());
//     }
// }