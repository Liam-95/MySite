import java.util.Random;

import Plotter.Plotter;

public class Sorting {

	final static int SMALL_DEMO_ARRAY = 10000;
	final static int BIG_DEMO_ARRAY = 100000000;
	final static int BUILDHEAP_VS_QUICK_LENGTH = 16;
	final static int MERGE_VS_QUICK_LENGTH = 16;
	final static int MERGE_VS_QUICK_SORTED_LENGTH = 16;
	final static int HEAP_VS_BUBBLE_LENGTH = 12;
	final static double T = 600.0;
	/**
	 * Sorts a given array using the quick sort algorithm. At each stage the pivot
	 * is chosen to be the righttmost element of the subarray.
	 * 
	 * Should run in average complexity of O(nlog(n)), and worst case complexity of
	 * O(n^2)
	 * 
	 * @param arr - the array to be sorted
	 */
	public static void quickSort(double[] arr) {
		int r = arr.length - 1;
		int p = 0;
		RealquickSort(arr, p, r);
	}
	/**
	 * calling the sorting function.
	 * 
	 * @param arr - the array to be sorted
	 * @param p - the left side of the array
	 * @param r - the right side of the array
	 */
	public static void RealquickSort(double[] arr, int p, int r) {
		if (p < r) {
			int q = Partition(arr, p, r);
			RealquickSort(arr, p, q - 1);
			RealquickSort(arr, q + 1, r);
		}
		return;
	}
	/**
	 *  using the Partition function in order to sort the elements acording to the pivot.
	 * 
	 * @param arr - the array to be sorted
	 * @param p - the left side of the array
	 * @param r - the right side of the array
	 */
	public static int Partition(double[] arr, int p, int r) {
		double pivot = arr[r];
		int i = p - 1;
		for (int j = p; j < r - 1; j++) {
			if (arr[j] < pivot) {
				i++;
				double temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
		double temp = arr[i + 1];
		arr[i + 1] = arr[r];
		arr[r] = temp;
		return (i + 1);
	}

	/**
	 * Sorts a given array using the merge sort algorithm.
	 * 
	 * Should run in complexity O(nlog(n)) in the worst case.
	 * 
	 * @param arr - the array to be sorted
	 */
	/**
	 * Sorts a given array using the merge sort algorithm.
	 * 
	 * Should run in complexity O(nlog(n)) in the worst case.
	 * 
	 * @param arr - the array to be sorted
	 */
	public static void mergeSort(double[] arr) {
		int p = 0;
		int r = arr.length - 1;
		RealMergeSort(arr, p, r);
	}
	/**
	 *  calling the mergesort algorithem to sort the array.
	 * 
	 * @param arr - the array to be sorted
	 * @param p - the left side of the array
	 * @param r - the right side of the array
	 */
	public static void RealMergeSort(double[] arr, int p, int r) {
		if (p < r) {
			int q = (p + r) / 2;
			RealMergeSort(arr, p, q);
			RealMergeSort(arr, q + 1, r);
			merge(arr, p, q, r);
		}
	}
	/**
	 *  calling the merge algorithem to merge the 2 sides of the diveded arrays.
	 * 
	 * @param arr - the array to be sorted
	 * @param p - the left side of the array
	 * @param r - the right side of the array
	 */
	public static void merge(double[] arr, int p, int q, int r) {
		int n1 = q - p + 1;
		int n2 = r - q;
		double[] L = new double[n1 + 1];
		double[] R = new double[n2 + 1];
		for (int i = 0; i < n1; i++) {
			L[i] = arr[p + i];
		}
		for (int j = 0; j < n2; j++) {
			R[j] = arr[q + 1 + j];
		}
		L[n1] = Double.POSITIVE_INFINITY;
		R[n2] = Double.POSITIVE_INFINITY;
		int i = 0;
		int j = 0;
		for (int k = p; k <= r; k++) {
			if (L[i] <= R[j]) {
				arr[k] = L[i];
				i++;
			} else {
				arr[k] = R[j];
				j++;
			}
		}
	}

	/**
	 * Builds a max-heap from the given array. That is, when using the resulting
	 * array to represent an almost complete binary tree The value of each node must
	 * be larger (or equal) to the value of any of its descendants. Should run in
	 * complexity O(n) in the worst case.
	 * 
	 * @param arr - the given array.
	 */
	public static void buildHeap(double[] arr) {
		int n = arr.length;
		for (int i = (n / 2) - 1; i >= 0; i--) {
			percDown(arr, n, i);
		}

	}
	/**
	 *  calling the mergesort algorithem to sort the array.
	 * 
	 * @param arr - the array to be sorted
	 * @param n - the size of the array
	 * @param i - the index which to be percolate by
	 */
	public static void percDown(double[] arr, int n, int i) {
		int large = i;
		int left = 2 * i + 1;
		int right = 2 * i + 2;
		if (left < n && arr[left] > arr[large]) {
			large = left;
		}
		if (right < n && arr[right] > arr[large]) {
			large = right;
		}
		if (large != i) {
			double temp = arr[i];
			arr[i] = arr[large];
			arr[large] = temp;
			percDown(arr, n, large);
		}
	}

	/**
	 * Sorts a given array using the heap sort algorithm.
	 * 
	 * Should run in complexity O(nlog(n)) in the worst case.
	 * 
	 * @param arr - the array to be sorted
	 */
	public static void heapSort(double[] arr) {
		int n = arr.length;
		buildHeap(arr);
		for (int i = n - 1; i > 0; i--) {
			double x = arr[0];
			arr[0] = arr[i];
			arr[i] = x;
			percDown(arr, i, 0);
		}
	}

	/**
	 * Sorts a given array using the bubble sort algorithm.
	 * 
	 * Should run in complexity O(n^2) in the worst case.
	 * 
	 * @param arr - the array to be sorted
	 */
	public static void bubbleSort(double[] arr) {
		boolean notDone = true;
		while (notDone) {
			boolean again = false;
			for (int i = 0; i < arr.length - 1; i++) {
				double current = arr[i];
				double next = arr[i + 1];
				if (current > next) {
					double temp = next;
					arr[i + 1] = arr[i];
					arr[i] = temp;
					again = true;
				}
			}
			if (again == false) {
				notDone = false;
			}
		}
	}

	public static void main(String[] args) {
		double [] teste = {12,21,7,13,9,36,2,5,3,19,7 };
		double [] testd = {46,31,51,71,31,10,21,8,13,11,41,16 };
		double [] testc = {55,1,61,21,3,27,17,2,9,20 };
		buildHeap(testc);
		for (int i = 0; i < testc.length; i++) {
			System.out.println(testc[i]);
		}
		
		//buildHeapVsQuick();
		//mergeVsQuick();
		//mergeVsQuickOnSortedArray();
		//heapSortVsBubble();
	}
	/**
	 * Compares the build heap algorithm against quick sort on random arrays
	 */
	public static void buildHeapVsQuick() {
		double[] quickTimes = new double[BUILDHEAP_VS_QUICK_LENGTH];
		double[] heapTimes = new double[BUILDHEAP_VS_QUICK_LENGTH];
		long startTime, endTime;
		Random r = new Random();
		for (int i = 0; i < BUILDHEAP_VS_QUICK_LENGTH; i++) {
			long sumQuick = 0;
			long sumHeap = 0;
			for (int k = 0; k < T; k++) {
				int size = (int) Math.pow(2, i);
				double[] a = new double[size];
				double[] b = new double[size];
				for (int j = 0; j < a.length; j++) {
					a[j] = r.nextGaussian() * 5000;
					b[j] = a[j];
				}
				startTime = System.currentTimeMillis();
				quickSort(a);
				endTime = System.currentTimeMillis();
				sumQuick += endTime - startTime;
				startTime = System.currentTimeMillis();
				buildHeap(b);
				endTime = System.currentTimeMillis();
				sumHeap += endTime - startTime;
			}
			quickTimes[i] = sumQuick / T;
			heapTimes[i] = sumHeap / T;
		}
		Plotter.plot("quick sort", quickTimes, "build heap", heapTimes);
	}

	/**
	 * Compares the merge sort algorithm against quick sort on random arrays
	 */
	public static void mergeVsQuick() {
		double[] quickTimes = new double[MERGE_VS_QUICK_LENGTH];
		double[] mergeTimes = new double[MERGE_VS_QUICK_LENGTH];
		long startTime, endTime;
		Random r = new Random();
		for (int i = 0; i < MERGE_VS_QUICK_LENGTH; i++) {
			long sumQuick = 0;
			long sumMerge = 0;
			for (int k = 0; k < T; k++) {
				int size = (int) Math.pow(2, i);
				double[] a = new double[size];
				double[] b = new double[size];
				for (int j = 0; j < a.length; j++) {
					a[j] = r.nextGaussian() * 5000;
					b[j] = a[j];
				}
				startTime = System.currentTimeMillis();
				quickSort(a);
				endTime = System.currentTimeMillis();
				sumQuick += endTime - startTime;
				startTime = System.currentTimeMillis();
				mergeSort(b);
				endTime = System.currentTimeMillis();
				sumMerge += endTime - startTime;
			}
			quickTimes[i] = sumQuick / T;
			mergeTimes[i] = sumMerge / T;
		}
		Plotter.plot("quick sort", quickTimes, "merge sort", mergeTimes);
	}

	/**
	 * Compares the merge sort algorithm against quick sort on pre-sorted arrays
	 */
	public static void mergeVsQuickOnSortedArray() {
		double[] quickTimes = new double[MERGE_VS_QUICK_SORTED_LENGTH];
		double[] mergeTimes = new double[MERGE_VS_QUICK_SORTED_LENGTH];
		long startTime, endTime;
		for (int i = 0; i < MERGE_VS_QUICK_SORTED_LENGTH; i++) {
			long sumQuick = 0;
			long sumMerge = 0;
			for (int k = 0; k < T; k++) {
				int size = (int) Math.pow(2, i);
				double[] a = new double[size];
				double[] b = new double[size];
				for (int j = 0; j < a.length; j++) {
					a[j] = j;
					b[j] = j;
				}
				startTime = System.currentTimeMillis();
				quickSort(a);
				endTime = System.currentTimeMillis();
				sumQuick += endTime - startTime;
				startTime = System.currentTimeMillis();
				mergeSort(b);
				endTime = System.currentTimeMillis();
				sumMerge += endTime - startTime;
			}
			quickTimes[i] = sumQuick / T;
			mergeTimes[i] = sumMerge / T;
		}
		Plotter.plot("quick sort on sorted array", quickTimes, "merge sort on sorted array", mergeTimes);
	}

	/**
	 * Compares the bubble sort algorithm against heap sort.
	 */
	public static void heapSortVsBubble() {
		double[] bubbleTimes = new double[HEAP_VS_BUBBLE_LENGTH];
		double[] heapTimes = new double[HEAP_VS_BUBBLE_LENGTH];
		long startTime, endTime;
		Random r = new Random();
		for (int i = 0; i < HEAP_VS_BUBBLE_LENGTH; i++) {
			long sumBubble = 0;
			long sumHeap = 0;
			for (int k = 0; k < T; k++) {
				int size = (int) Math.pow(2, i);
				double[] a = new double[size];
				double[] b = new double[size];
				for (int j = 0; j < a.length; j++) {
					a[j] = r.nextGaussian() * 5000;
					b[j] = a[j];
				}
				startTime = System.currentTimeMillis();
				bubbleSort(a);
				endTime = System.currentTimeMillis();
				sumBubble += endTime - startTime;
				startTime = System.currentTimeMillis();
				heapSort(b);
				endTime = System.currentTimeMillis();
				sumHeap += endTime - startTime;
			}
			bubbleTimes[i] = sumBubble / T;
			heapTimes[i] = sumHeap / T;
		}
		Plotter.plot("bubble sort", bubbleTimes, "heap sort", heapTimes);
	}
}
