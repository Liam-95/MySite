/*
Assignment number: 6.4
File Name : fadeToBlack.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
public class fadeToBlack {
    /**
     * program get 2 command line arguments of image name and number of steps. read
     * the image given by the users using read fucntion from ImageEditing class.
     * showing the picture in segmented version using the segment function from
     * ImageEditing class. show the image using thw show function from ImageEditing
     * class. then showing morphing image from clourful image to black and white,
     * using morph function from ImageEditing class.
     * 
     * @return - void.
     */
    public static void main(String args[]) {
        String image = args[0];
        int steps = Integer.parseInt(args[1]);
        int[][][] photo = ImageEditing.read(image);
        int[][][] segmented = ImageEditing.copy(photo);
        ImageEditing.segement(segmented);
        ImageEditing.show(segmented);
        ImageEditing.morph(photo, segmented, steps);
    }

}