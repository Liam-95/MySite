/*
Assignment number: 6.1
File Name : ImageEditing.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
public class ImageEditing {
	public static void main(String args[]) {
		show(read("cake.ppm"));
	}

	public static final int pixSize = 3;

	/**
	 * making a copy of the current image. The input array is assumed to contain
	 * integers in the range [0,255].
	 * 
	 * @param source - the image to copy.
	 */
	public static int[][][] copy(int[][][] source) {
		int[][][] theCopy = new int[source.length][source[0].length][pixSize];
		for (int i = 0; i < source.length; i++) {
			for (int j = 0; j < source[i].length; j++) {
				for (int j2 = 0; j2 < pixSize; j2++) {
					theCopy[i][j][j2] = source[i][j][j2];
				}
			}
		}
		return theCopy;

	}

	/**
	 * Renders an image using StdDraw. The input array is assumed to contain
	 * integers in the range [0,255]. With the third dimension being of size 3.
	 * 
	 * @param pic - the image to show.
	 */
	public static void show(int[][][] pic) {
		StdDraw.setCanvasSize(pic[0].length, pic.length);
		int height = pic.length;
		int width = pic[0].length;
		StdDraw.setXscale(0, width);
		StdDraw.setYscale(0, height);
		StdDraw.show(30);
		for (int i = 0; i < height; i++){
		    for (int j = 0; j < width; j++){
				StdDraw.setPenColor(pic[i][j][0], pic[i][j][1], pic[i][j][2] );
				StdDraw.filledRectangle(j + 0.5, height - i - 0.5, 0.5, 0.5);
		    }
		}
		StdDraw.show();
		
	}

	/**
	 * read an image given by the users. The output array is containing integers in
	 * the range [0,255]. With the third dimension being of size 3.
	 * 
	 * @param filename - the image name to read.
	 * @return - the image as an 3D arrays.
	 */
	public static int[][][] read(String filename) {
		StdIn.setInput(filename);
		// notForUse
		StdIn.readString();
		int columnsInt = StdIn.readInt();
		int rowInt = StdIn.readInt();
		// not for use
		StdIn.readInt();
		int[][][] ans = new int[rowInt][columnsInt][pixSize];
		for (int i = 0; i < rowInt; i++) {
			for (int j = 0; j < columnsInt; j++) {
				for (int k = 0; k < pixSize; k++) {
					ans[i][j][k] = StdIn.readInt();
				}
			}
		}
		return ans;
	}

	/**
	 * print an array of pixels. The output array is the arrsy standing for the
	 * image that is given by the user the integer range is [0,255], With the third
	 * dimension being of size 3.
	 * 
	 * @param source - the image to print.
	 */

	public static void print(int[][][] source) {
		for (int i = 0; i < source.length; i++) {
			for (int j = 0; j < source[0].length; j++) {
				for (int k = 0; k < pixSize; k++) {
					StdOut.printf("%5s", source[i][j][k]);
				}
			}
			System.out.println();
		}
	}

	/**
	 * flip Horizontally an image. The input array is assumed to contain integers in
	 * the range [0,255]. With the third dimension being of size 3.
	 * 
	 * @param source - the image to be fliped Horizontally.
	 * @return - the image fliped Horizontally
	 */

	public static int[][][] flipHorizontally(int[][][] source) {
		int[][][] ans = new int[source.length][source[0].length][pixSize];
		for (int i = 0; i < source.length; i++) {
			for (int j = 0; j < source[0].length; j++) {
				ans[i][j] = source[i][source[0].length - j - 1];
			}
		}
		return ans;
	}

	/**
	 * flip vertically an image. The input array is assumed to contain integers in
	 * the range [0,255]. With the third dimension being of size 3.
	 * 
	 * @param source - the image to be fliped vertically.
	 * @return - the image fliped vertically
	 */

	public static int[][][] flipvertically(int[][][] source) {
		int[][][] ans = new int[source.length][source[0].length][pixSize];
		for (int i = 0; i < source[i].length; i++) {
			ans[i] = source[source.length - 1 - i];
		}
		return ans;
	}

	/**
	 * iterate over the image pixels and calcualting thier average color, The input
	 * array is assumed to contain integers in the range [0,255], With the third
	 * dimension being of size 3.
	 * 
	 * @param pixel - the image to calculate average pixels colors.
	 * @return - the average color in RGB scale.
	 */

	public static double average(int[][][] pixel) {
		int[][][] ans = copy(pixel);
		int count = 0;
		double averageRgb = 0;
		int sum = 0;
		for (int i = 0; i < pixel.length - 1; i++) {
			for (int j = 0; j < pixel[0].length - 1; j++) {
				int temp = 0;
				for (int k = 0; k < pixSize; k++) {
					temp += ans[i][j][k];
				}
				count += 3;
				sum += temp;
			}
		}
		averageRgb = sum / count;
		return averageRgb;
	}

	/**
	 * Segmentation of Black and White, using average function to comute the
	 * threshold, any pixel average larger the the threshold will turn to white. the
	 * array is assumed to contain integers in the range [0,255]. With the third
	 * dimension being of size 3.
	 * 
	 * @param source - the image to produce a Segmentation of Black and White for.
	 * @return - the original image segmented to black and white
	 */

	public static int[][][] segement(int[][][] source) {
		double pixelcolor = 0;
		double thresHold = average(source);
		for (int i = 0; i < source.length; i++) {
			for (int j = 0; j < source[0].length; j++) {
				for (int k = 0; k < pixSize; k++) {
					pixelcolor += source[i][j][k];
				}
				pixelcolor = (pixelcolor / pixSize);
				if (pixelcolor >= thresHold) {
					source[i][j][0] = 255;
					source[i][j][1] = 255;
					source[i][j][2] = 255;
				} else {
					source[i][j][0] = 0;
					source[i][j][1] = 0;
					source[i][j][2] = 0;
				}
				pixelcolor = 0;
			}
		}
		return source;
	}

	/**
	 * scaling an image to dimension given by the user, The input array is assumed
	 * to contain integers in the range [0,255]. With the third dimension being of
	 * size 3. the input integers are asuumed mark the necessary scale.
	 * 
	 * @param source - the image to scale.
	 * @param width  - the new width to scale to.
	 * @param height - the new height to scale to.
	 * @return - the original image, stretched/shrunk to the new dimensions
	 */

	public static int[][][] scale(int[][][] source, int width, int height) {
		int[][][] ans = new int[height][width][pixSize];
		double heightScale = source.length / height;
		double widthScale = source[0].length / width;
		for (int i = 0; i < ans.length; i++) {
			for (int j = 0; j < ans[i].length; j++) {
				ans[i][j] = source[(int) (i * heightScale)][(int) (j * widthScale)];
			}
		}

		return ans;
	}

	/**
	 * blend the color of 2 pixels. The output array is the array standing for the
	 * blended color of the pixel that is given by the user and by spesific ratio,
	 * the function check that both arrays are of pixels (size 3), and assuming to
	 * contain the integer range of [0,255].
	 * 
	 * @param pixel1 - the first pixel for the blending.
	 * @param pixel2 - the second pixel for the blending.
	 * @param alpha  - the rate of blending.
	 */

	public static int[] blend(int[] pixel1, int[] pixel2, double alpha) {
		int[] blended = new int[pixel1.length];
		if (pixel1.length == pixel2.length && pixel1.length == pixSize) {
			for (int i = 0; i < pixel1.length; i++) {
				blended[i] = (int) ((alpha) * (pixel1[i]) + (1 - alpha) * (pixel2[i]));
			}
		} else {
			return new int[0];
		}
		return blended;
	}

	/**
	 * combining two pictures using the blend function. The output array is the
	 * array standing for the combined pictures using the ratio given by the user,
	 * the function assuming both array are integers arrays in the range [0,255],
	 * With the third dimension being of size 3.
	 * 
	 * @param source1 - the first picture fo rcombining.
	 * @param source2 - the second picture for combining.
	 * @param alpha   - the rate of blending.
	 */

	public static int[][][] combine(int[][][] source1, int[][][] source2, double alpha) {
		int[][][] combined = new int[source1.length][source1[0].length][pixSize];
		for (int i = 0; i < source1.length; i++) {
			for (int j = 0; j < source1[i].length; j++) {
				combined[i][j] = blend(source1[i][j], source2[i][j], alpha);
			}
		}
		return combined;
	}

	/**
	 * shifts from source image to target gradually, over a n iterations, while
	 * showing the steps. if size mismath scales to secong image using scale
	 * function.
	 *
	 * @param source - image to start from
	 * @param target - image to end at
	 * @param n      - number of steps to take
	 */

	public static void morph(int[][][] source, int[][][] target, int n) {
		for (double i = 0; i <= n; i++) {
			double alpha = (n - i) / n;
			if (source.length != target.length || source[0].length != target[0].length) {
				target = scale(target, source[0].length, source.length);
			}
			show(combine(source, target, alpha));
		}
	}
}
