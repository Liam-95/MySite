/*
Assignment number: 6.3
File Name : Editor2.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
public class Editor2 {
    /**
     * program get 3 command line arguments. read an image given by the users(first
     * argument). then scaling the image using ImageEditing class (second and third
     * arguments)
     * 
     * @return - void.
     */
    public static void main(String args[]) {
        String image = args[0];
        int width = Integer.parseInt(args[1]);
        int height = Integer.parseInt(args[2]);
        int[][][] source = ImageEditing.read(image);
        source = ImageEditing.scale(source, width, height);
        ImageEditing.show(source);

    }

}