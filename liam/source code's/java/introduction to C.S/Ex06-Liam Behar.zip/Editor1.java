/*
Assignment number: 6.2
File Name : Editor1.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
public class Editor1 {

    /**
     * the program takes 2 command line arguments: picture name, choosen operation.
     * the progeam can do 3 opperation for any given picture. horizontall flip,
     * verticall flip, segmented version.
     * 
     * @return - void.
     **/
    public static void main(String args[]) {
        String fileName = args[0];
        String operation = args[1];
        // horizontally flipped
        String fh = "fh";
        // vertically flipped
        String fv = "fv";
        // segmented version
        String se = "se";
        if (operation.equals(fh)) {
            int[][][] checkHorizontal = ImageEditing.read(fileName);
            ImageEditing.show(ImageEditing.flipHorizontally(checkHorizontal));
        }
        if (operation.equals(fv)) {
            int[][][] checkvertical = ImageEditing.read(fileName);
            ImageEditing.show(ImageEditing.flipvertically(checkvertical));
        }
        if (operation.equals(se)) {
            int[][][] checkSegement = ImageEditing.read(fileName);
            ImageEditing.show(ImageEditing.segement(checkSegement));
        }
    }

}