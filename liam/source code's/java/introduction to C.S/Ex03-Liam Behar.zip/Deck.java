/*
Assignment number: 3.1
File Name : Deck.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
/**
 * Provides services for creating and shuffling a deck of cards.
 */
public class Deck {

    public static void main(String[] args) {
        String[] deck = createDeck();
        printDeck(deck);
        printDeck(shuffled(deck));
        printDeck(deck);
    }

    /**
     * Builds and returns a deck of cards. Each card has a suit and a rank.
     */
    public static String[] createDeck() {
        // Builds a deck of cards​
        String[] suit = { "\u2660", "\u2666", "\u2665", "\u2663" };
        String[] rank = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A" };
        int Nsuit = suit.length;
        int Nrank = rank.length;
        int N = Nsuit * Nrank;

        String[] deck = new String[N];
        for (int i = 0; i < Nrank; i++) {
            for (int j = 0; j < Nsuit; j++) {
                deck[Nsuit * i + j] = suit[j] + rank[i];
            }
        }
        return deck;
    }

    /**
     * Prints the given deck of cards.
     */
    public static void printDeck(String[] deck) {
        // Prints the shuffled deck​
        int N = deck.length;
        for (int i = 0; i < N; i++)
            System.out.print(deck[i] + " ");
        System.out.println();
    }

    /**
     * Returns a new, shuffled deck of cards. The given deck is not changed.
     */
    public static String[] shuffled(String[] deck) {
        int N = deck.length;
        String[] deckCopy;
        deckCopy = new String[N];
        for (int i = 0; i < N; i++) {
            deckCopy[i] = deck[i];
        }
        for (int i = 0; i < N - 1; i++) {
            int r = i + (int) (Math.random() * (N - i));
            String temp = deckCopy[r];
            deckCopy[r] = deckCopy[i];
            deckCopy[i] = temp;
        }
        return deckCopy;
    }
}
