public class Test {

  public static void main(String args[]) {
    //registerTest();
    //memoryTest();
    //ComputerTest();
    Math.random();
  }

  public static void registerTest() {
    Register r1 = new Register();
    r1.setValue(10);
    System.out.println(r1);
    Register r2 = new Register(20);
    System.out.println(r2);
    r1.addOne();
    r2.setValue(r1.getValue());
    System.out.println(r2);
    String test = r1.toString();
    System.out.println(test + 9);
  }

  public static void memoryTest() {
    Memory m = new Memory(100);
    System.out.println(m);
    m.setValue(0, 100);
    m.setValue(1, 200);
    m.setValue(2, -17);
    int v = m.getValue(1);
    System.out.println(v);
    System.out.println(m.getValue(0));
    m.setValue(1, 300);
    m.setValue(3, 34);
    m.setValue(4, 234);
    m.setValue(8, -17);
    m.setValue(9, 59);
    m.setValue(90, 36);
    m.setValue(91, 23);
    m.setValue(97, 56);
    m.setValue(98, 0);
    m.setValue(99, 1);
    System.out.printf(m.toString());
  }
  public static void ComputerTest(){
    // // //test load method
    // Computer tester = new Computer();
    // tester.reset(); 
    // tester.loadProgram("program1.vic");
    // System.out.println(tester);
    // //test run for load and write
    // Computer test1 = new Computer();
    // test1.reset();
    // test1.loadProgram("program1.vic");
    // test1.run();
    // System.out.println(test1);
    // //test add method
    // Computer test2 = new Computer();
    // test2.reset();
    // test2.loadProgram("program2.vic");
    // test2.run();
    // System.out.println(test2);
    // // test sub method
    // Computer test3 = new Computer();
    // test3.reset();
    // test3.loadProgram("program3.vic");
    // test3.run();
    // System.out.println(test3);
    // // test store method
    // Computer test4 = new Computer();
    // test4.reset();
    // test4.loadProgram("program4.vic");
    // test4.run();
    // System.out.println(test4);
    // // test read method and set input method
    // Computer test5 = new Computer();
    // test5.reset();
    // test5.loadProgram("program5.vic");
    // test5.setInput("input1.dat");
    // test5.run();
    // System.out.println(test5);
    // //test goto and gotoz methods
    // Computer test6 = new Computer();
    // test6.reset();
    // test6.loadProgram("program6.vic");
    // test6.setInput("input2.dat");
    // test6.run();
    // System.out.println(test6);
    // testing gotop
    // Computer test7 = new Computer();
    // test7.reset();
    // test7.loadProgram("max2.vic");
    // test7.setInput("input3.dat");
    // test7.run();
    // System.out.println(test7);
  }
}
