/*
Assignment number: 8.1
File Name : Register.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
/**
 * Represents a register. A register is the basic storage unit of the Vic
 * computer.
 */
public class Register {

	private int value; // the current value of this register

	/** Constructs a register and sets its value to the given value. */
	public Register(int value) {
		this.value = value;
	}

	/** Constructs a register and sets its value to 0. */
	public Register() {
		this.value = 0;
	}

	/** Sets the value of this register to the given value. */
	public void setValue(int value) {
		this.value = value;
	}

	/** Adds 1 to the value of this register. */
	public void addOne() {
		this.value = this.value + 1;
	}

	/** Returns the value of this register, as an int. */
	public int getValue() {
		int get;
		get = this.value;
		return get;

	}

	/** Returns the value of this register, as a String. */
	public String toString() {
		String ans = "";
		int decValue = this.value;
		ans = Integer.toString(decValue);
		return ans;
	}
}
