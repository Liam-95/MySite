/**
 * Represents a memory unit, which is an indexed sequence of registers. Enables
 * reading from, or writing to, any individual register according to a given
 * index. The index is typically called "address". The addresses run from 0 to
 * the memory's size, minus 1.
 */
public class Memory {

	private Register[] m; // an array of Register objects

	/*
	Assignment number: 8.2
	File Name : Memory.java
	Name : Liam Behar
	Email : liam.behar@post.idc.ac.il
	*/
	/** 
	* Constructs a memory of size registers, and sets all the register values to 0.
	 */
	public Memory(int size) {
		this.m = new Register[size];
		for (int i = 0; i < size; i++) {
			this.m[i] = new Register(0);
		}
	}

	/** Sets the values of all the registers in this memory to 0. */
	public void reset() {
		for (int i = 0; i < m.length; i++) {
			this.m[i] = new Register(0);
		}

	}

	/** Returns the value of the register whose address is the given address. */
	public int getValue(int address) {
		Register r = this.m[address];
		return r.getValue();
	}

	/** Sets the register in the given address to the given value. */
	public void setValue(int address, int value) {
		Register s = this.m[address];
		s.setValue(value);
	}

	/**
	 * Returns a subset of the memory's contents, as a formated string.
	 * Specifically: Returns the first 10 registers (where the top of the program
	 * normally resides) and the last 10 registers (where the variables normally
	 * reside). For each register, returns the register's address, and value.
	 */
	public String toString() {
		String str = "";
		for (int j = 0; j < 10; j++) {
			Register h = m[j];
			str += j + "  " + h.toString() + " " + "\n";
		}
		str += "..."+ "\n";
		for (int i = 90; i <100; i++) {
			Register h = m[i];
			if (i == 99) {
				str += i + "  " + h.toString();
			}
			else {
				str += i + "  " + h.toString() + " " +"\n";
			}
		}
		return str;
	}
}
