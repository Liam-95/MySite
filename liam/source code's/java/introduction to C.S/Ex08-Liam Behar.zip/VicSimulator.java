/*
Assignment number: 8.4
File Name : VicSimulator.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
public class VicSimulator {
	public static void main(String[] args) {
		Computer vic = new Computer();
		vic.reset();
		vic.loadProgram(args[0]);
		if (args[1].length() != 0) {
			vic.setInput(args[1]);
		}
		vic.run();
		System.out.println(vic);
	}
}