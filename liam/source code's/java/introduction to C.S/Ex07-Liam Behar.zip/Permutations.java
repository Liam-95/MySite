/*
Assignment number: 7.2
File Name : Permutations.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
/******************************************************************************
 * Compilation: javac Permutations.java Execution: java Permutations n
 *
 * Enumerates all permutations on n elements. Two different approaches are
 * included.
 *
 * % java Permutations 3 abc acb bac bca cab cba
 *
 ******************************************************************************/

public class Permutations {

    private static void permutations(String elements, String prefix) {
        if (elements.length() == 0)
            System.out.println(prefix);
        else {
            for (int i = 0; i < elements.length(); i++) {
                char pre = elements.charAt(i);
                String others = elements.substring(0, i) + elements.substring(i + 1);
                permutations(others,prefix + pre);
            }
        }
    }

    public static void main(String[] args) {
        String all = "";
        String alphabet = "abcdefghijklmnopqrstuvwxyz";
        for (int i = 0; i < Integer.parseInt(args[0]); i++) {
            all += alphabet.charAt(i);
        }
        permutations(all, "");
    }
}
