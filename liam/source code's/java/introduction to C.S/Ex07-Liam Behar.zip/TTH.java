/*
Assignment number: 7.3 + 7.4
File Name : TTH.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/

public class TTH {

    private static double calcP(int n) {
        double prob = 0;
        if (n < 3) {
            return 0;
        }
        prob = 0.5 * calcP(n - 1) + 0.25 * calcP(n - 2) + 1 / (Math.pow(2, n));
        return prob;
    }

    private static double calcPmem(int n, double[] memory) {
            if (n < 3) {
            return 0;
            }
            if (memory[n] == 0) {
                memory[n] = 0.5 * calcPmem(n - 1, memory) + 0.25 * calcPmem(n - 2, memory) +  (Math.pow(0.5, n));
            }
        
        return memory[n];
    }

    // this main function is provided
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        double duration = 0;
        double durationMem = 0;
        int reps = 1000;
        double startTime, endTime;

        for (int i = 0; i < reps; i++) {
            startTime = System.nanoTime();
            calcP(n);
            endTime = System.nanoTime();
            duration += (endTime - startTime) / reps;

            double[] memory = new double[n + 1];
            startTime = System.nanoTime();
            calcPmem(n, memory);
            endTime = System.nanoTime();
            durationMem += (endTime - startTime) / reps;
        }
        StdOut.println("P(" + n + ") = " + calcP(n));
        StdOut.println("no memoization: " + duration / 100);
        StdOut.println("with memoization: " + durationMem / 100);
    }
}
