import java.awt.Color;
/*
Assignment number: 7.5
File Name : FractalTree.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
public class FractalTree {
    
    private static final int recursionDepth = 14;
    private static final Color rootColor = Color.BLACK;
    private static final Color leafColor = new Color(195, 255, 112);
    private static final double trunkWidth = 0.008;
    private static final double factor = 0.8;
    private static final int canvasWidth = 600;
    private static final int canvasHeight = 400;
    private static final double branchAngle = Math.PI / 4;
    private static final double anglePerturb = 6.0;
    private static final double minWidth = 0.002;
    // private static int counter = 0;

    private static Color adjustColor(int level) {
        double w = (double) level / recursionDepth;
        double red = w * rootColor.getRed() + (1 - w) * leafColor.getRed();
        double green = w * rootColor.getGreen() + (1 - w) * leafColor.getGreen();
        double blue = w * rootColor.getBlue() + (1 - w) * leafColor.getBlue();

        return new Color((int) red, (int) green, (int) blue);
    }

    private static double adjustWidth(int level) {
        double w = (double) level / recursionDepth;
        return Math.max(minWidth, trunkWidth * w);
    }

    public static void drawBranch(int level, double x0, double y0, double length, double angle) {
        if (level == 0) {
            return;
        }
        double branch = Math.random() * length;
        length = factor * length;
        StdDraw.setPenColor(adjustColor(level));
        StdDraw.setPenRadius(adjustWidth(level));

        double x1 = x0 + branch * Math.cos(angle);
        double y1 = y0 + branch * Math.sin(angle);
        StdDraw.line(x0, y0, x1, y1);
        double plusAngle = angle + Math.random() * branchAngle * anglePerturb/level;
        double minusAngle = angle - Math.random() * branchAngle * anglePerturb/level;

        drawBranch(level - 1, x1, y1, length, plusAngle);
        drawBranch(level - 1, x1, y1, length, minusAngle);

    }

    public static void main(String[] args) {
        StdDraw.setXscale(0, canvasWidth);
        StdDraw.setYscale(0, canvasHeight);
        drawBranch(recursionDepth, canvasWidth / 2.0, -50, 100, Math.PI / 2);
    }
}
