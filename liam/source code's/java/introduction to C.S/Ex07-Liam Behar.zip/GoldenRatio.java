/*
Assignment number: 7.1
File Name : GoldenRatio.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
public class GoldenRatio {

    static double goldenRec(int n) {
        double ans = 0;
        if (n > 0) {
            ans = 1 + 1 / goldenRec(n - 1);
        } else {
            return 1;
        }
        return ans;
    }

    static double goldenIter(int n) {
        double lower = 0;
        int size = n;
        for (int i = 0; i < size+2; i++) {
            lower = 1 + 1 / (double) lower;
        }
        return lower;
    }

    public static void main(String[] args) {
        int input = Integer.parseInt(args[0]);
        double gold1 = goldenRec(input);
        double gold2 = goldenIter(input);
        System.out.println(gold1);
        System.out.println(gold2);

    }
}