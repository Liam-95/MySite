public class Team {
    Player[] arr;
    Player[]  keeper;
    String shirtColor;
    int size;
    int sum;


    Team(String shirtColor) {
        this.arr = new Player[5];
        this.keeper = new Player[5];
        this.shirtColor = shirtColor;
        this.size = 0;
        this.sum = 0;
    }

    public void AddPlayer(Player add) {
        if (size < 5) {
            arr[size] = add;
            keeper[size] = add;
            size++;
            this.sum = sum + add.rank;
        }
    }
    public String toString() {
        StringBuilder st= new StringBuilder();
        for (int i = 0; i < size; i++) {
            st.append(arr[i] + " ");
        }
        return st.toString();
    }
    public String KeepertoString() {
        StringBuilder st= new StringBuilder();
        for (int i = 0; i < size; i++) {
            st.append((i+1) + "." + keeper[i].name + ", ");
        }
        return st.toString();
    }

    public void clean(){
        this.size=0;
        this.sum=0;
    }

}