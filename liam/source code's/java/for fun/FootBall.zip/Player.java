public class Player {
    public static int playerNumber = 1;

    // fileds of Player class
    // player name:
    String name;
    // player number:
    int number;
    // ranks are from 1 to 10:
    int rank;
   

    // generte new player
    Player(String name, int rank) {
        this.name = name;
        this.number = playerNumber++;
        this.rank = rank;
    }

    // print player
    public String toString() {
        StringBuilder pl = new StringBuilder();
        pl.append("Player Name: " + this.name + ". ");
        //pl.append("player number: " +this.number + ", ");
        //pl.append("player rank: " + this.rank + ".");
        return pl.toString();
    }

    // update player rank
    public void UpdateRank(int newRank) {
        this.rank = newRank;
    }
}
