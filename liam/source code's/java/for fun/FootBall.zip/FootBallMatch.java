public class FootBallMatch {

    public static void main(String[] args) {
        // liam = new Player("Liam Behar", 5);
        Player idan = new Player("Idan Firizen", 5);
        Player amit = new Player("Amit Shani", 7);
        Player eden_s = new Player("Eden Sharin", 9);
        Player eden_g = new Player("Eden Gershon", 6);
        Player yuval = new Player("Yuval Tayar", 5);
        Player omer = new Player("Omer Chen", 9);
        Player dean = new Player("Dean Torgaman", 8);
        //Player adir = new Player("Adir Boker", 8);
        //Player tom_a = new Player("Tom Avron", 7);
        Player tom_b = new Player("Tom Bhasan", 8);
        Player bar = new Player("Bar Eshel", 5);
        Player meir = new Player("Meir ???", 5);
        Player yarin = new Player("Yarin ???", 5);
        Player mor = new Player("Mor Hozez", 10);
        Player yam = new Player("Yam Danel", 4);
        Player amir = new Player("Amir Afota", 5);
        //Player omri = new Player("Omri Peleg", 8);
        Player braoner = new Player("Aviv Brauner", 6);
        Player[] allPlayers = { meir, idan, amit, eden_s, eden_g, yuval, omer, dean, tom_b, bar, mor, yam,
                amir, braoner,yarin };
        Player[] TallPlayers = { meir, idan, amit, eden_s, eden_g, yuval, omer, dean, tom_b, bar, mor, yam,
                amir ,braoner,yarin };
        Team team1 = new Team("White");
        Team team2 = new Team("Black");
        Team team3 = new Team("Red");
        ToTeams(allPlayers, team1, team2, team3);
        int sum1 = team1.sum;
        int sum2 = team2.sum;
        int sum3 = team3.sum;
        int fmax = Math.max(sum1, sum2);
        int max = Math.max(fmax, sum3);
        int fmin = Math.min(sum1, sum2);
        int min = Math.min(fmin, sum3);
        int diff = max - min;
        while (diff > 5) {
            System.arraycopy(TallPlayers, 0, allPlayers, 0, TallPlayers.length);
            team1.clean();
            team2.clean();
            team3.clean();
            ToTeams(allPlayers, team1, team2, team3);
            sum1 = team1.sum;
            sum2 = team2.sum;
            sum3 = team3.sum;
            fmax = Math.max(sum1, sum2);
            max = Math.max(fmax, sum3);
            fmin = Math.min(sum1, sum2);
            min = Math.min(fmin, sum3);
            diff = max - min;
            if (diff <= 5) {
                break;
            }
        }
        PrintTeams(team1, team2, team3);
    }

    public static void ToTeams(Player[] allPlayers, Team team1, Team team2, Team team3) {
        int done = 0;
        while (done < 5) {
            int flipPlayer = (int) (Math.random() * allPlayers.length);
            Player temp = allPlayers[flipPlayer];
            if (temp != null) {
                team1.AddPlayer(temp);
                allPlayers[flipPlayer] = null;
                done++;
            }
        }
        done = 0;
        while (done < 5) {
            int flipPlayer = (int) (Math.random() * allPlayers.length);
            Player temp = allPlayers[flipPlayer];
            if (temp != null) {
                team2.AddPlayer(temp);
                allPlayers[flipPlayer] = null;
                done++;
            }
        }
        done = 0;
        while (done < 5) {
            int flipPlayer = (int) (Math.random() * allPlayers.length);
            Player temp = allPlayers[flipPlayer];
            if (temp != null) {
                team3.AddPlayer(temp);
                allPlayers[flipPlayer] = null;
                done++;
            }
        }
    }

    public static void PrintTeams(Team team1, Team team2, Team team3) {
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.print("Team 1: \n" + team1.toString() + "\nTeam shirt color: " + team1.shirtColor + "."
                + "\nTeam Strength: " + team1.sum + "." + '\n');
        System.out.print("GoalKeepers: " + team1.KeepertoString());
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.print("Team 2: \n" + team2.toString() + "\nTeam shirt color: " + team2.shirtColor + "."
                + "\nTeam Strength: " + team2.sum + "." + '\n');
        System.out.print("GoalKeepers: " + team2.KeepertoString());
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.print("Team 3: \n" + team3.toString() + "\nTeam shirt color: " + team3.shirtColor + "."
                + "\nTeam Strength: " + team3.sum + "." + '\n');
        System.out.print("GoalKeepers: " + team3.KeepertoString());
        System.out.println();
        System.out.println();

        int flip1 = (int) (Math.random() * 3) + 1;
        int flip2 = (int) (Math.random() * 3) + 1;
        while (flip1 == flip2) {
            flip1 = (int) (Math.random() * 3) + 1;
        }
        System.out.println("The first teams to play are: " + flip1 +" and " + flip2 + "." );
        System.out.println();
        System.out.println("GOOD LUCK!!!");
    }

}