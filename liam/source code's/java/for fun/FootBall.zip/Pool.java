public class Pool {
    Player liam = new Player("Liam Behar", 5);
    Player idan = new Player("Idan", 5);
    Player amit = new Player("Amit", 7);
    Player eden_s = new Player("Eden", 9);
    Player eden_g = new Player("Eden", 6);
    Player yuval = new Player("Yuval", 5);
    Player omer = new Player("Omer", 9);
    Player dean = new Player("Dean", 8);
    Player[] pool = { liam, idan, amit, eden_s, eden_g, yuval, omer, dean };
}