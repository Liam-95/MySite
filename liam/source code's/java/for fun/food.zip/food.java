import java.util.Scanner;

public class food {
	static final String[] day = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
	static final String[] order = { "cuisine-1", "cuisine-2", "cuisine-3", "cuisine-4"};

	public static void main(String[] args) {

		long startTime = System.nanoTime();
		System.out.println(
				"\n Hello friend! it is really nice seeing you again, please press: \n\n 1 if you want me to do 'deliveryDay' coin flip. \n 2 if you want me to do 'what to eat' coin flip. \n 3 if you want me to do 'dissert' coin flip. \n\n and if you all done please press 0 so i could go to sleep.");
		Scanner scanner = new Scanner(System.in);
		int chosenNumber;
		try {
			while ((chosenNumber = scanner.nextInt()) != 0) {
				if (chosenNumber == 1) {
					deliveryDay();
				} else if (chosenNumber == 2) {
					eatWhat();
				} else if (chosenNumber == 3) {
					Dissert();
				} else {
					System.out.println("\n"
							+ "please wirth down one of the number on the list! \n press: \n 1 for deliveryDay coin flip \n 2 for what to eat coin flip \n 3 for dissert coin flip \n if you all done press 0 so i could go to sleep.");
				}
			}
		} catch (Exception e) {
			System.out.println(
					"\nAs far as i know Number Theory, you have not entered a digit, as i'm deeply offended i'm going home, bye!");
			scanner.close();
			return;
		}
		scanner.close();
		long elapsedNanos = (System.nanoTime() - startTime);
		System.out.println("it took you only " + elapsedNanos * Math.pow(10, -9) + " seconds");
		System.out.println("bon appétit!");
		return;

	}

	public static void deliveryDay() {
		int flip = (int) (Math.random() * day.length);
		System.out.println();
		System.out.println(" I suggests you order on: " + day[flip]);
		System.out.println();
	}

	public static void eatWhat() {
		int flip = (int) (Math.random() * order.length);
		System.out.println();
		System.out.println(" I suggests you order: " + order[flip]);
		System.out.println();
	}

	public static void Dissert() {
		double flip = Math.random();
		if (flip > 0.5) {
			System.out.println();
			System.out.println(" finish with GOLDA ");
			System.out.println();
		} else
			System.out.println(" finish with PILLOWS ");
		System.out.println();

	}
}