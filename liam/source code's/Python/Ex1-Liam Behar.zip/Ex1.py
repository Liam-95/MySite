def evaluate_formula(formula):
    """ function to valuate prefix notation
    args: the formula """
    stack = []
    char = len(formula) - 1
    while char >= 0:
        number = ""
        current = formula[char]
        while ('0' <= current <= '9') or (current == '.') or ((current == '-') and ('0' <= formula[char+1] <= '9')):
            number = current + number
            char -= 1
            current = formula[char]
        if len(number):
            stack.append(float(number))
        if (current == '*' or current == '/' or current == '+' or current == '-'):
            first = stack.pop()
            second = stack.pop()
            if current == '+':
                stack.append(first + second)
            elif current == '-':
                stack.append(first - second)
            elif current == '*':
                stack.append(first * second)
            elif current == '/':
                stack.append(first / second)
        char -= 1
    if stack:
        print(stack.pop())


def validate_israeli_id(id_number):
    """ simple function to validate an israeli id
    args: id number"""
    good = True
    if len(id_number) != 9:
        good = False
        print("invalid")
    digits = [int(id_number[0]), int(id_number[1]) * 2, int(id_number[2]), int(id_number[3]) * 2,
              int(id_number[4]), int(id_number[5]) *
              2, int(id_number[6]), int(id_number[7]) * 2,
              int(id_number[8])]
    for i, num in enumerate(digits):
        if num > 9:
            temp = str(num)
            new_digit = int(temp[0]) + int(temp[1])
            digits[i] = new_digit
    sum_all = sum(digits)
    if sum_all % 10 != 0 and good:
        print("invalid")
        good = False
    if good:
        print("valid")


def find_largest_palindrome():
    """ finding largest_palindrome using two 3 digits numbers"""
    num1 = 0
    num2 = ""
    for i in range(100, 1000):
        for j in range(100, 1000):
            product = i * j
            if is_palindrome(str(product)) and (product > num1):
                num1 = product
    num2 = str(num1)[::2]
    print(num1, ',', num2)


def is_palindrome(word):
    """ for the use of find_largest_palindrome()"""
    is_it = reverse(word)
    if len(word) != len(is_it):
        return False
    for i in range(len(word)):
        if is_it[i] != word[i]:
            return False
    return True


def reverse(word):
    """ for the use of find_largest_palindrome()"""
    ans = ""
    for i in range(len(word)):
        ans += word[len(word) - 1 - i]
    return ans


def remove_forbidden_characters(sentence, forbidden_characters):
    """ simple function to remove unwanted chars from a string
    args: string, unwanted chars as string"""
    ans = ""
    skip = False
    for c in sentence:
        for i in forbidden_characters:
            if c == i:
                skip = True
                break
        if not skip:
            ans += c
        skip = False
    print(ans)


if __name__ == "__main__":
    pass
