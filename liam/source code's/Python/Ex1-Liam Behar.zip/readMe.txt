implementation of few different function in python


functions API included in the source code