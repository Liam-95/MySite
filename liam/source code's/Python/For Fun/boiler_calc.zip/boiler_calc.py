# Python program to decide if water electrical heating is required today every day
# using openWhetherMaps API

import suntime
import datetime
import pause
import requests
import smtplib
import ssl
from email.message import EmailMessage
from getpass import getpass

LATITUDE = 32.0853
LONGITUDE = 34.781769

gmail_user = ""
gmail_password = ""

clouds_percentage_hourly = []
my_list = []
my_counter = 0
today = ""


def dates_data_gen():
    """ generate relevent time data using datetime and suntime library's for the use of timed_job """
    global today
    today = str(datetime.datetime.now())[
            :str(datetime.datetime.now()).index(" ")]
    sun = suntime.Sun(LATITUDE, LONGITUDE)
    time_rise_full = str(datetime.datetime.utcfromtimestamp(
        sun.get_local_sunrise_time(datetime.datetime.now()).timestamp()))
    time_set_full = str(datetime.datetime.utcfromtimestamp(
        sun.get_local_sunset_time(datetime.datetime.now()).timestamp()))
    hour_fix_rise = int(time_rise_full[-7]) + 2
    hour_fix_set = int(time_set_full[-7]) + 1
    time_rise_final = time_rise_full[:-7] + str(hour_fix_rise) + time_rise_full[-6:]
    time_set_final = time_set_full[:-7] + str(hour_fix_set) + time_set_full[-6:]
    my_list.append(today)
    my_list.append(time_rise_final)
    my_list.append(time_set_final)


def timed_job():
    """collect whether data from openWhetherMaps, specifically cloudiness percentage"""
    # Enter your API key here
    api_key = "bfbe15869d91bca61a2a7a43f9dba711"

    # base_url variable to store url
    base_url = "http://api.openweathermap.org/data/2.5/weather?"

    # Give city name
    city_name = "Tel aviv"

    # complete url address
    complete_url = base_url + "appid=" + api_key + "&q=" + city_name + "&units=metric"

    # get method of requests module
    # return response object
    response = requests.get(complete_url)

    # json method of response object
    # convert json format data into
    # python format data
    x = response.json()

    # Now x contains list of nested dictionaries
    y = x["main"]

    clouds_all = x["clouds"]

    clouds_percentage_hourly.append(float(clouds_all["all"]))

    global my_counter
    my_counter += 1


def clean_every():
    my_list.clear()
    clouds_percentage_hourly.clear()
    global my_counter
    my_counter = 0
    global today
    today = ""


if __name__ == '__main__':
    """main method for the use of boiler_calc"""
    while True:
        print("Welcome!, program is Starting")
        if len(gmail_user) == 0:
            print("please provide the following information:")
            gmail_user = input("Gmail Email:")
            gmail_password = getpass('Password:')
        clean_every()
        dates_data_gen()
        now_time = datetime.datetime.now()
        sun_set = datetime.datetime.strptime(my_list[2], '%Y-%m-%d %H:%M:%S')
        tomorrow_reformatted = str(datetime.date.today() + datetime.timedelta(days=1))
        this_year = today[:today.index("-")]
        this_month = today[today.index("-") + 1:today.index("-") + 3]
        this_day = today[today.index("-") + 4:]
        sunrise_hour = int(my_list[1][my_list[1].index(":") - 2:my_list[1].index(":")])
        sunset_hour = int(my_list[2][my_list[2].index(":") - 2:my_list[2].index(":")])
        buffer = (now_time.hour - sunrise_hour)
        if now_time <= sun_set:
            print("I'm Starting my calculation for today =)")
            while my_counter < (sunset_hour - sunrise_hour - buffer):
                needed_time = datetime.datetime(int(this_year), int(this_month), int(this_day), int(sunrise_hour) + 1)
                if now_time < needed_time:
                    pause.until(
                        datetime.datetime(int(this_year), int(this_month), int(this_day), int(sunrise_hour) + 1))
                timed_job()
                now_time = datetime.datetime.now()
                print("just added another hour =)", now_time)
                if my_counter < (sunset_hour - sunrise_hour):
                    pause.sleep(3600)
            if len(clouds_percentage_hourly) != 0:
                average = sum(clouds_percentage_hourly) / len(clouds_percentage_hourly)
            else:
                average = 0
            msg = EmailMessage()
            msg["From"] = gmail_user
            msg["To"] = [gmail_user]
            msg["Subject"] = 'update about the boiler'
            my_massage = ""
            if average > 80:
                my_massage = "Hi i think you better start your boiler for long time!,average is > 80"
            elif average > 40:
                my_massage = "Hi i think you better start your boiler, 40 < average is < 80"
            else:
                my_massage = "Hi i don't think you're gonna need your boiler today, average is < 40"
            msg.set_content(my_massage)
            context = ssl.create_default_context()
            with smtplib.SMTP("smtp.gmail.com", port=587) as smtp:
                smtp.starttls(context=context)
                smtp.login(msg["From"], gmail_password)
                smtp.send_message(msg)
                print("I have just sent you Email!")
        tom_year = tomorrow_reformatted[:tomorrow_reformatted.index("-")]
        tom_month = tomorrow_reformatted[tomorrow_reformatted.index("-") + 1:tomorrow_reformatted.index("-") + 3]
        tom_day = tomorrow_reformatted[tomorrow_reformatted.index("-") + 4:]
        print("It's look like i'm all done for today...,can't wait for tomorrow!,just keep me open =)")
        pause.until(datetime.datetime(int(tom_year), int(tom_month), int(tom_day), 1, 00))