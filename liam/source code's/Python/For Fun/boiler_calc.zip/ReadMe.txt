use this program to smartly control your electric boiler.

achieved by calculating the average cloud coverage throughout the day (sunrise to sunset)
and sending an email with the appropriate calculation and a suggestion on whether to turn on your electric heater or not.

can be upgrade in the future, so don't hesitate to send me an email with your request =)
enjoy.
