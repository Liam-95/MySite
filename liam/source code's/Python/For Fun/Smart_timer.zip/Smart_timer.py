# Python program to decide if water electrical heating is required today every day
# using openWhetherMaps API

import datetime
import suntime
import pause
import requests
import smtplib
import ssl
from email.message import EmailMessage
from getpass import getpass

# Tel-aviv geo data
LATITUDE = 32.0853
LONGITUDE = 34.781769
Gmail_port = 587

# global vars
gmail_user = ""
gmail_password = ""

clouds_percentage_hourly = []
my_counter = 0
average = -1
today = datetime.datetime.date(datetime.datetime.now())
time_rise_final = datetime.datetime.now()
time_set_final = datetime.datetime.now()
tomorrow_reformatted = datetime.date.today() + datetime.timedelta(days=1)
now_time = datetime.datetime.now().astimezone()
buffer = (now_time.hour - time_rise_final.hour) - 1
never_ran = True


def first_login():
    print("Welcome!")
    while True:
        print("please provide the following information:")
        global gmail_user
        gmail_user = input("Gmail Email:")
        global gmail_password
        gmail_password = getpass('Password:')
        try:
            with smtplib.SMTP("smtp.gmail.com", port=Gmail_port) as test_smtp:
                test_context = ssl.create_default_context()
                test_smtp.starttls(context=test_context)
                test_smtp.login(gmail_user, gmail_password)
        except Exception as e:
            print(e)
        else:
            print("\nI'm in!\n")
            return


def clean_every():
    clouds_percentage_hourly.clear()
    global my_counter
    my_counter = 0
    global today
    today = ""
    global average
    average = 0


def dates_data_gen():
    """ generate relevent time data using datetime and suntime library's for the use of timed_job """
    global today
    today = datetime.datetime.date(datetime.datetime.now())
    sun = suntime.Sun(LATITUDE, LONGITUDE)
    time_rise_full = sun.get_sunrise_time().astimezone()
    time_set_full = sun.get_sunset_time().astimezone()
    global now_time
    now_time = datetime.datetime.now().astimezone()
    global tomorrow_reformatted
    tomorrow_reformatted = datetime.date.today() + datetime.timedelta(days=1)
    global time_rise_final
    time_rise_final = time_rise_full.replace(time_rise_full.year, time_rise_full.month, time_rise_full.day,
                                             time_rise_full.hour, time_rise_full.minute)
    global time_set_final
    time_set_final = time_set_full.replace(time_set_full.year, time_set_full.month, time_set_full.day,
                                           time_set_full.hour, time_set_full.minute)
    global buffer
    buffer = (now_time.hour - time_rise_final.hour) - 1


def time_mechanism():
    if now_time < time_set_final.replace(hour=time_set_final.hour - 1):
        first_time = True
        while True:
            if now_time < time_rise_final:
                pause.until(
                    datetime.datetime(time_rise_final.year, time_rise_final.month, time_rise_final.day,
                                      time_rise_final.hour + 1))
            if first_time:
                print("\nStarting today calculation =)\n")
                first_time = False
            timed_job()
            print(f"added my {my_counter} hour =)", str(now_time.time())[0:5])
            if my_counter < (time_set_final.hour - time_rise_final.hour - buffer - 1):
                pause.sleep(min(3600, int((time_set_final - datetime.datetime.now().astimezone()).total_seconds())))
            else:
                global never_ran
                never_ran = False
                global average
                average = sum(clouds_percentage_hourly) / len(clouds_percentage_hourly) if len(
                    clouds_percentage_hourly) else []
                send_mail(int(average))
                return


def timed_job():
    """helper function for the use of time_mechanism
    collect whether data from openWhetherMaps, specifically cloudiness percentage"""
    api_key = "bfbe15869d91bca61a2a7a43f9dba711"
    base_url = "http://api.openweathermap.org/data/2.5/weather?"
    city_name = "Tel aviv"
    complete_url = base_url + "appid=" + api_key + "&q=" + city_name + "&units=metric"
    response = requests.get(complete_url)
    whether_date = response.json()
    clouds_percentage_hourly.append(float(whether_date["clouds"]["all"]))
    global my_counter
    my_counter += 1
    global now_time
    now_time = datetime.datetime.now().astimezone()


def send_mail(average_in):
    """helper function for the use of time_mechanism"""
    msg = EmailMessage()
    msg["From"] = gmail_user
    msg["To"] = [gmail_user]
    msg["Subject"] = 'important update by your script!'
    # my_massage = ""
    if average_in > 80:
        my_massage = f"Hi i think you better start your boiler for long time!,average is {average}%\n"
    elif average_in > 40:
        my_massage = f"Hi i think you better start your boiler, average is {average}%\n"
    elif average_in >= 0:
        my_massage = f"Hi i don't think you're gonna need your boiler today, average is {average}%\n"
    else:
        my_massage = "it looks like i had a problem, sorry for the inconvenience,let's try tomorrow again =)"
    msg.set_content(my_massage + str(clouds_percentage_hourly))
    context = ssl.create_default_context()
    with smtplib.SMTP("smtp.gmail.com", port=Gmail_port) as smtp:
        smtp.starttls(context=context)
        smtp.login(msg["From"], gmail_password)
        smtp.send_message(msg)
        print("I have just sent you Email!")


def end_of_the_day():
    """print to console end for today massage whether because done or not been started in relevant time """
    global never_ran
    if never_ran:
        print("but it is to late for me to do anything today,open me up at sunrise or just keep me open here")
        never_ran = False
    else:
        print("It's look like i'm all done for today...,can't wait for tomorrow!,just keep me open =)")


def wait():
    """wait function, we wait here for a new day"""
    pause.until(
        datetime.datetime(tomorrow_reformatted.year, tomorrow_reformatted.month, tomorrow_reformatted.day, 1, 00))


if __name__ == '__main__':
    """main method for the use of boiler_calc"""
    first_login()
    while True:
        clean_every()
        dates_data_gen()
        time_mechanism()
        end_of_the_day()
        wait()
