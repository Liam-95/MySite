import yaml
from errors import ItemNotExistError, TooManyMatchesError, ItemAlreadyExistsError
from item import Item
from shopping_cart import ShoppingCart


class Store:
    def __init__(self, path):
        """constructor for the store class, build the store item,initialise shopping_cart
         and key_value_dict for the use of sorting_as_requested """
        with open(path) as inventory:
            items_raw = yaml.load(inventory, Loader=yaml.FullLoader)['items']
        self._items = self._convert_to_item_objects(items_raw)
        self._shopping_cart = ShoppingCart()
        self._key_value_dict = dict()

    @staticmethod
    def _convert_to_item_objects(items_raw):
        return [Item(item['name'],
                     int(item['price']),
                     item['hashtags'],
                     item['description'])
                for item in items_raw]

    def get_items(self) -> list:
        """getter method"""
        return self._items

    def search_by_name(self, item_name: str) -> list:
        """
        search_by_name for item in the store, the returned list contains the relevant search results
        sorted as requested
        :param item_name:
        :return sorted list of results:
        """
        # search items by names, if an item was matched and! it is not in our shopping list add it to the matched list
        matched_names = []
        for iter_item in self._items:
            if iter_item.name.find(item_name) != -1 and iter_item.name not in \
                    self._shopping_cart.shopping_list_name:
                matched_names.append(iter_item)
        # sort the list by the requested algorithm and return the list
        return self.sorting_as_requested(matched_names)

    def search_by_hashtag(self, hashtag: str) -> list:
        """search_by_hashtag for item in the store, the returned list contains the relevant search results
                 sorted as requested"""
        # search items by hashtags, if an item was matched and! it is not in our shopping list,
        # add it to the matched list
        matched_hash = []
        for iter_item in self._items:
            # construct temp list with all tags of the item
            temp = [x for x in iter_item.hashtags]
            # if hashtag is member of the list and item is not currently in shopping cart then add it to matched_hash
            if hashtag in temp and iter_item.name not in self._shopping_cart.shopping_list_name:
                matched_hash.append(iter_item)
        # sort the list by the requested algorithm and return the list
        return self.sorting_as_requested(matched_hash)

    def add_item(self, item_name: str):
        """add item to the ShoppingCart if the
            item to add is mapped as one to one with Item in the store,if multiple items matched raise
            TooManyMatchesError if no math raise ItemNotExistError """
        # item\s that suspected to be added"
        to_add_list = [x for x in self._items if x.name.find(item_name) != -1]
        # if to many items in the list i.e more then 1 raise TooManyMatchesError
        # if list is empty raise ItemNotExistError
        if len(to_add_list) > 1:
            raise TooManyMatchesError
        if not len(to_add_list):
            raise ItemNotExistError
        else:
            # send the item to add method of shopping_cart
            try:
                self._shopping_cart.add_item(to_add_list[0])
            except ItemAlreadyExistsError as AlreadyExists:
                # if item do not exists, catch and raise ItemNotExistError
                raise AlreadyExists

    def remove_item(self, item_name: str):
        """remove item from the ShoppingCart if the
            item to remove is mapped as one to one with Item in the ShoppingCart, if multiple items matched raise
            TooManyMatchesError if no math raise ItemNotExistError """
        # item\s that suspected to be removed"
        to_remove_list = [x for x in self._shopping_cart.shopping_list if x.name.find(item_name) != -1]
        # if to many items in the list i.e more then 1 raise TooManyMatchesError
        # if list is empty raise ItemNotExistError
        if len(to_remove_list) > 1:
            raise TooManyMatchesError
        if not len(to_remove_list):
            raise ItemNotExistError
        else:
            # send the item to remove method of shopping_cart
            try:
                self._shopping_cart.remove_item(to_remove_list[0].name)
            except ItemNotExistError as NotExist:
                # if item do not exists, catch and raise ItemNotExistError
                raise NotExist

    def checkout(self) -> int:
        """checkout method,calls _shopping_cart.get_subtotal"""
        # using self._shopping_cart.get_subtotal method to get the subtotal
        return self._shopping_cart.get_subtotal()

    def sorting_as_requested(self, for_sort):
        """first method out of 3 for the use of search_by_name, this is the main driver of the sorting
        first sort by lexi-order with Item __gt__ implementation
         then sort according to tags in common using built-in sorted method"""
        # lexicographical sorting,using the implementation of item.__gt__ and item.__eq__
        for_sort.sort()
        # if shopping cart is non empty, tush add hashtags sort on top of the lexicographical sort.
        if len(self._shopping_cart.shopping_list):
            # update the common tag lists with the right number of occurrences
            self.update_dict()
            # return sorted list as requested, when key is given by the retrieve_values_per_cart_list method
            # and sorting is done in reverse order (big------->small)
            return sorted(for_sort, key=self.retrieve_values_per_cart_list, reverse=True)
        else:
            return for_sort

    def update_dict(self):
        """second method out of 3,
         update the dictionary such that the keys are the tags that are currently in the shopping cart
         and the values are the number of occurrences"""
        for x in self._shopping_cart.shopping_list_hash:
            # for every key:item ,if key is already init then add 1 to the count else set to zero adn add one
            for item in x:
                self._key_value_dict[item] = self._key_value_dict.get(item, 0) + 1

    def retrieve_values_per_cart_list(self, item1):
        """
        third method out of 3 - compare function,
        receive item from the search list each time,
        check against the key_value_dict who has more common tags with current shopping list in any
        :param one item to be evaluate:
        :return:
        """
        counter = 0
        # for each item received, count the number of tags that are common with the tags currently in my shopping list
        for this_hash in item1.hashtags:
            counter += self._key_value_dict.get(this_hash, 0)
        # return true if more tags in common in second item and we need to swap
        return counter
