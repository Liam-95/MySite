from errors import ItemAlreadyExistsError, ItemNotExistError
from item import Item


class ShoppingCart:

    def __init__(self):
        """constructor for ShoppingCart object, initialise: shopping_list,shopping_list_hash,shopping_list_name"""
        # store the list by the items object
        self.shopping_list = []
        # store the current items in shopping_list hashes only
        self.shopping_list_hash = []
        # store the current items in shopping_list names only
        self.shopping_list_name = []

    def add_item(self, item: Item):
        """add item to the shopping_list if item not in the list else raise ItemAlreadyExistsError
        if item do not exists also updating the shopping_list_hash list and shopping_list_name list"""
        # check if item already in shopping_list
        if item in self.shopping_list:
            raise ItemAlreadyExistsError
        # else add the item to my object fields
        self.shopping_list.append(item)
        self.shopping_list_hash.append(item.hashtags)
        self.shopping_list_name.append(item.name)

    def remove_item(self, item_name: str):
        """remove item from the shopping_list if item in the list else raise ItemNotExistError
                if item do exists also removing it from the shopping_list_hash list and shopping_list_name list"""
        # check if this name in my shopping_list
        for current_item in self.shopping_list:
            if current_item.name == item_name:
                self.shopping_list.remove(current_item)
                self.shopping_list_hash.remove(current_item.hashtags)
                self.shopping_list_name.remove(current_item.name)
                return
        # else item not exists error
        raise ItemNotExistError

    def get_subtotal(self) -> int:
        """return the total price of all item objects in the shopping_list, return 0 if shopping_list is empty"""
        subtotal = 0
        # for all items in shopping_list ,sum the price filed
        for item in self.shopping_list:
            subtotal += item.price
        return subtotal
