class Item:
    def __init__(self, item_name: str, item_price: int, item_hashtags: list, item_description: str):
        self.name = item_name
        self.price = item_price
        self.hashtags = item_hashtags
        self.description = item_description

    def __str__(self) -> str:
        return f'Name:\t\t\t{self.name}\n' \
               f'Price:\t\t\t{self.price}\n' \
               f'Description:\t{self.description}'

    def __repr__(self):
        """repr representation of type Item"""
        return f"{type(self).__name__} name:{self.name}Price:{self.price}Description:{self.description}"

    def __eq__(self, other):
        """equals implementation for Item object, i.e iff all files are equal"""
        return self.name == other.name and self.description == other.description \
               and self.price == other.price and self.hashtags == other.hashtags

    def __gt__(self, other):
        """greater then implementation for type Item, based on String implementation of greater then"""
        return self.name > other.name

    def __lt__(self, other):
        """lower then implementation for type Item, based on String implementation of lower then"""
        return self.name < other.name

    def __iter__(self):
        """iterator for Item object, based on iterator implementation of lists"""
        return iter(self.hashtags)
