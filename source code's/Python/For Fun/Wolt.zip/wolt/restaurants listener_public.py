import json
import requests
import winsound
from time import sleep
from itertools import islice
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from sys import argv
from pathlib import Path

first_time = True
rapidapi = ""
email_to = ""
# base urls
generic_file_json = {"0. burgers": ["https://wolt.com/en/isr/tel-aviv/restaurant/vitrina",
                                    "https://wolt.com/en/isr/tel-aviv/restaurant/vitrina-ibn-gvirol",
                                    "https://wolt.com/en/isr/tel-aviv/restaurant/america-burgers",
                                    "https://wolt.com/en/isr/tel-aviv/restaurant/prozdor-burger"],
                     "1. vitrinas": ["https://wolt.com/en/isr/tel-aviv/restaurant/vitrina",
                                     "https://wolt.com/en/isr/tel-aviv/restaurant/vitrina-ibn-gvirol"],
                     "2. McDonalds": ["https://wolt.com/en/isr/tel-aviv/restaurant/mcdonalds-rothschild"],
                     "3. nam": ["https://wolt.com/en/isr/tel-aviv/restaurant/mcdonalds-rothschild"],
                     "4. super yuda": ["https://wolt.com/en/isr/tel-aviv/venue/super-yuda-yehuda-hamacabi"],
                     "5. nordinyo": ["https://wolt.com/en/isr/tel-aviv/venue/nordinyo-we-like-you-too"],
                     "6. zozobra": ["https://wolt.com/en/isr/tel-aviv/restaurant/zozobra"],
                     "7. otello": ["https://wolt.com/en/isr/tel-aviv/restaurant/otello-herzel",
                                   "https://wolt.com/en/isr/tel-aviv/restaurant/otellogelato"],
                     "8. taqueria": ["https://wolt.com/en/isr/tel-aviv/restaurant/taqueria-1"]}


def get_page_html(url):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36"}
    page = requests.get(url, headers=headers)
    return page.content


def check_vendor_is_open(page_html):
    soup = BeautifulSoup(page_html, 'html.parser')
    venue_offline = soup.findAll("div", {
        "data-test-value": "venue-offline"})
    venue_closed = soup.findAll("div", {
        "data-test-value": "venue-closed"})
    venue_preorder_only = soup.findAll("div", {
        "data-test-value": "venue-preorder-only"})
    return len(venue_offline) == 0 and len(venue_closed) == 0 and len(venue_preorder_only) == 0


def check_restaurants(url):
    page_html = get_page_html(url)
    if check_vendor_is_open(page_html):
        tell_me(url)
        return True
    else:
        print(f"The restaurant: {url[url.rfind('/') + 1:]} is closed!")
        return False


def tell_me(url):
    print(f"The restaurant: {url[url.rfind('/') + 1:]} is open!")
    duration = 2000  # milliseconds
    freq = 1000  # Hz
    winsound.Beep(freq, duration)
    try:
        chrome_options = Options()
        chrome_options.add_experimental_option("detach", True)
        chrome_options.add_experimental_option('excludeSwitches', ['enable-logging'])
        driver = webdriver.Chrome()
        driver.get(url)
    except Exception:
        print("Tried to open the browser but failed!")
    if rapidapi:
        send_mail(url[url.rfind('/') + 1:])
    sleep(100)


def send_mail(restaurant):
    payload = "{\r\n    \"personalizations\": [\r\n        {\r\n            \"to\": [\r\n                {\r\n                    \"email\": \"%\"\r\n                }\r\n            ],\r\n            \"subject\": \"Resturant opend\"\r\n        }\r\n    ],\r\n    \"from\": {\r\n        \"email\": \"!\"\r\n    },\r\n    \"content\": [\r\n        {\r\n            \"type\": \"text/plain\",\r\n            \"value\": \"the resutarn is#\"\r\n        }\r\n    ]\r\n}"

    headers = {
        'content-type': "application/json",
        'x-rapidapi-host': "rapidprod-sendgrid-v1.p.rapidapi.com",
        'x-rapidapi-key': rapidapi
    }

    temp = str(payload)
    new_payload = temp[:temp.index("#")] + " " + str(restaurant) + temp[temp.index("#") + 1:]
    new_payload1 = new_payload[:new_payload.index("%")] + "" + str(email_to) + new_payload[
                                                                               new_payload.index("%") + 1:]
    new_payload2 = new_payload1[:new_payload1.index("!")] + "" + str(email_to) + new_payload1[
                                                                                 new_payload1.index(
                                                                                     "!") + 1:]
    res = requests.request("POST", "https://rapidprod-sendgrid-v1.p.rapidapi.com/mail/send", data=new_payload2,
                           headers=headers)
    if res.status_code == 200 or res.status_code == 202:
        print("I have just sent you Email!")
    else:
        print("Mail sending failed")


def check_if_open(restaurant):
    try:
        for rest in restaurant:
            if check_restaurants(rest):
                return True
        return False
    except KeyboardInterrupt:
        return KeyboardInterrupt


def first_time_file():
    fle = Path('restaurants_list.json')
    fle.touch(exist_ok=True)
    sleep(0.1)
    with open("restaurants_list.json", 'r+', 1) as f:
        try:
            json.load(f)
        except json.decoder.JSONDecodeError:
            f.seek(0)
            f.truncate()
            json.dump(generic_file_json, f, indent=4)
            f.flush()
            return


def choose_option():
    global first_time
    if first_time:
        first_time_file()
        sleep(0.3)
    with open("restaurants_list.json", 'r+', 1) as f:
        data = json.load(f)
        while True:
            # command line argument for faster load time
            if len(argv) == 2 and first_time:
                get_rest = argv[1]
                first_time = False
            else:
                # get user input
                get_rest = input(
                    f"Which restaurants to listen to? to add a new on write: 'name' 'url'  {json.dumps(data, indent=4, sort_keys=True)} \n")
            # got an index to the list
            if get_rest.isnumeric() and int(get_rest) <= len(data):
                selected_key = next(islice(iter(data), int(get_rest), int(get_rest) + 1))
                print(f"You selected: {selected_key[selected_key.index(' '):].strip()}")
                for key, value in data.items():
                    if key == selected_key:
                        return value
            # got a name and url
            elif 'https://wolt.com/' in get_rest:
                new_index = len(data)
                if len(get_rest.split()) == 2:
                    updated_key = get_rest[:get_rest.rfind(' ')].strip()
                    updated_value = [get_rest[get_rest.find(' '):].strip()]
                else:
                    updated_key = get_rest.split()[:1][0]
                    updated_value = [x for x in get_rest.split()[1:]]
                f.seek(0)
                f.truncate()
                data.update(
                    {f"{new_index}. {updated_key}": updated_value})
                json.dump(data, f, indent=4)
                return updated_value
            # got invalid input!
            print("Not a valid choice!")


if __name__ == '__main__':
    print("Starting!")
    if rapidapi:
        email_to = input("To whom should I send the email to?")
    option = choose_option()
    while True:
        try:
            if check_if_open(option):
                ans = input('To leave or listen to another? : Y/n ')
                if ans.lower() == 'y':
                    exit(0)
                else:
                    option = choose_option()
            else:
                sleep(4)
        except KeyboardInterrupt as e:
            while True:
                ans = input('To leave ? : Y/n ')
                if ans.lower() == 'y':
                    exit(0)
                elif ans.lower() == 'n':
                    ans = input('Choose another restaurant or keep this one? : K (keep)/ a (another) ')
                    if ans.lower() == 'y':
                        break
                    elif ans.lower() == 'a':
                        option = choose_option()
                        break
