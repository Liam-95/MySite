Usage is pretty self explanatory. If you would like to get and email in addition to the beep sound,
Pelase edit the rapidapi varialbe and add a rapidapi key for the "SendGrid!" api.
enjoy.