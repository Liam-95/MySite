# program to decide if water electrical heating is required today every day
# using accuweather API

import datetime
import suntime
import pause
import requests
from geopy.geocoders import Nominatim
import smtplib
import ssl
from email.message import EmailMessage
from getpass import getpass

# global vars
tel_aviv_code = "215854"
Gmail_port = 587
api_key = "szaFhgvhrUz9tDZzzFj4oY4aonUpK9Wi"


class SmartTimer:
    def __init__(self):
        self.LATITUDE = 32.0853
        self.LONGITUDE = 34.7818
        self.gmail_user = ""
        self.gmail_password = ""
        self.city_code = ""
        self.time_rise_final = datetime.datetime.now()
        self.time_set_final = datetime.datetime.now()
        self.tomorrow_reformatted = datetime.date.today() + datetime.timedelta(days=1)
        self.now_time = datetime.datetime.now().astimezone()
        self.buffer = (self.now_time.hour - self.time_rise_final.hour) - 1
        self.dict_time = {}
        self.sun = suntime.Sun(0, 0)
        first_login(self)


def first_login(first):
    print("Welcome!")
    print("please provide the following information:")
    while True:
        city = input("city name:")
        if city.lower() == "tel aviv":
            first.city_code = tel_aviv_code
            print("OK")
            break
        # asking for location key
        base_url_location = "http://dataservice.accuweather.com/locations/v1/cities/search?apikey="
        if city.find(" ") + 1:
            city_location = city[:city.index(" ")] + "%20" + city[city.index(" ") + 1:]
        else:
            city_location = city + "%20"
        complete_url_location = base_url_location + api_key + "&q=" + city_location
        response_location = requests.get(complete_url_location)
        location_data = response_location.json()
        if len(location_data):
            try:
                location_data_set = location_data[0]
            except Exception:
                print("cannot accesses servers today, try again tomorrow \ngoing to sleep")
                wait()
                response_location = requests.get(complete_url_location)
                location_data = response_location.json()
                location_data_set = location_data[0]
            first.city_code = location_data_set.get('Key')
            city = location_data_set.get('LocalizedName')
            print("OK")
            break
        else:
            print("please enter a valid location name")
    while True:
        first.gmail_user = input("Gmail Email:")
        first.gmail_password = getpass('Password:')
        try:
            with smtplib.SMTP("smtp.gmail.com", port=Gmail_port) as test_smtp:
                test_context = ssl.create_default_context()
                test_smtp.starttls(context=test_context)
                test_smtp.login(first.gmail_user, first.gmail_password)
        except Exception as e:
            print(e)
        print("\nI'm in!\n")
        if first.city_code != tel_aviv_code:
            try:
                geolocator = Nominatim(user_agent="Smart_boiler_timer")
                first.LONGITUDE = geolocator.geocode(city).longitude
                first.LATITUDE = geolocator.geocode(city).latitude
                return
            except Exception:
                print("problem connecting to geolocator services")
                exit(1)
        else:
            break


def clean_every():
    now.dict_time.clear()
    now.buffer = 0


# noinspection SpellCheckingInspection
def dates_data_gen():
    """ generate relevant time data using datetime and suntime library's for the use of timed_job """
    now.sun = suntime.Sun(now.LATITUDE, now.LONGITUDE)
    now.now_time = datetime.datetime.now().astimezone()
    now.tomorrow_reformatted = datetime.date.today() + datetime.timedelta(days=1)
    now.time_rise_final = now.sun.get_sunrise_time().astimezone()
    now.time_set_final = now.sun.get_sunset_time().astimezone()
    now.buffer = (now.now_time.hour - now.time_set_final.hour)


def time_mechanism():
    if now.now_time < now.time_set_final:
        print("waiting for sunset =)\n")
        pause.until(now.time_set_final - datetime.timedelta(hours=1))
        now.now_time = datetime.datetime.now().astimezone()
        print("computing today results=)\n")
        average = timed_job(1)
        try:
            send_mail(average)
        except Exception as e:
            print(e)
    else:
        ans = input("you are past sunset, do you want me to calculate today results? [y/n] ")
        if ans == 'n':
            return
        try:
            average = timed_job(0)
            send_mail(average)
        except Exception as e:
            print(e)


def timed_job(reg):
    """helper function for the use of time_mechanism
    collect whether data from accuweather, specifically cloudiness percentage"""
    # got location key,getting whether data
    complete_url_whether = f"http://dataservice.accuweather.com/currentconditions/v1/{now.city_code}/historical/24?apikey={api_key}&details=true"
    total_response_whether = 0
    try:
        total_response_whether = requests.get(complete_url_whether).json()
    except Exception:
        print("connection problem,no data added")
        return
    hours_size = now.time_set_final.hour - now.time_rise_final.hour
    sum_clouds = 0
    if reg:
        for cover in total_response_whether[:hours_size]:
            clouds_percentage_now = cover.get('CloudCover')
            at_time = cover.get('LocalObservationDateTime').split('T')[1].split('+')[0]
            sum_clouds += float(clouds_percentage_now)
            now.dict_time[at_time] = str(clouds_percentage_now) + "%"
    else:
        for cover in total_response_whether[now.buffer:now.buffer + hours_size]:
            clouds_percentage_now = cover.get('CloudCover')
            at_time = cover.get('LocalObservationDateTime').split('T')[1].split('+')[0]
            sum_clouds += float(clouds_percentage_now)
            now.dict_time[at_time] = str(clouds_percentage_now) + "%"
    return sum_clouds / hours_size


def send_mail(average_in):
    """helper function for the use of time_mechanism"""
    msg = EmailMessage()
    msg["From"] = now.gmail_user
    msg["To"] = [now.gmail_user]
    msg["Subject"] = 'important update by your script!'
    # my_massage = ""
    if average_in >= 80:
        my_massage = f"Hi i think you better start your boiler for long time!,average is {round(average_in, 2)}%\n"
    elif average_in >= 40:
        my_massage = f"Hi i think you better start your boiler, average is {round(average_in, 2)}%\n"
    elif average_in >= 0:
        my_massage = f"Hi i don't think you're gonna need your boiler today, average is {round(average_in, 2)}%\n"
    else:
        my_massage = "it looks like i had a problem, sorry for the inconvenience,let's try tomorrow again =)\n"
    msg.set_content(
        f"{my_massage}append below is the cloud coverage per hour i have collected today:\n{now.dict_time}")
    context = ssl.create_default_context()
    with smtplib.SMTP("smtp.gmail.com", port=Gmail_port) as smtp:
        smtp.starttls(context=context)
        smtp.login(msg["From"], now.gmail_password)
        smtp.send_message(msg)
        print("I have just sent you Email!")


def end_of_the_day():
    """print to console end for today massage whether because done or not been started in relevant time """
    print("It's look like i'm all done for today...,can't wait for tomorrow!,just keep me open =)")


def wait():
    """wait function, we wait here for a new day"""
    pause.until(now.sun.get_local_sunrise_time(now.tomorrow_reformatted))


if __name__ == '__main__':
    """main method for the use of boiler_calc"""
    now = SmartTimer()
    while True:
        clean_every()
        dates_data_gen()
        time_mechanism()
        end_of_the_day()
        wait()
