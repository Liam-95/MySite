Follow the program and enjoy.

(you may need to install a python interpreter locally on your machine)
