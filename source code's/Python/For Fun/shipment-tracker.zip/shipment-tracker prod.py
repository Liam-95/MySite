import requests
import json
import smtplib
import ssl
import sys
from email.message import EmailMessage
from tqdm import tqdm
from time import sleep
from getpass import getpass

toWho = ""
fromWho = ""
current = 0

url = "https://order-tracking.p.rapidapi.com/trackings/realtime"
tracking = ""
carrier = ""
payload = ""
headers = {
    'content-type': "application/json",
    'x-rapidapi-host': "order-tracking.p.rapidapi.com",
    'x-rapidapi-key': "ccec74c624mshed47edc3153eee4p1c3245jsn0ed8590ad572"
}


def first_login():
    global current
    global payload
    global fromWho
    global toWho
    global password
    print("Welcome! lets start:\n")
    fromWho = input("Enter your gmail address:")
    password = getpass('Enter your gmail password:')

    try:
        with smtplib.SMTP("smtp.gmail.com", port=587) as test_smtp:
            test_context = ssl.create_default_context()
            test_smtp.starttls(context=test_context)
            test_smtp.login(fromWho, password)
    except Exception as e:
        print("Cannot access you mail account,stopping execution.")
        sys.exit(1)
    print("I'm in!\n")
    toWho = input("To whom you want to send updates?[ if to yourself type \'me' ]: ")
    while True:
        again = False
        carrier = input("Carrier name:")
        tracking = input("Tracking number provided to you by carrier:")
        if toWho.lower() == "me":
            toWho = fromWho
        prefix = "{\n    \"tracking_number\": \""
        post_tracking = "\",\n    \"carrier_code\": \""
        suffix = "\"\n}"
        payload = prefix + tracking + post_tracking + carrier + suffix
        try:
            response = requests.request("POST", url, data=payload, headers=headers)
            json_data = json.loads(response.text)
            needf = json_data["data"]["items"][0]["origin_info"]["trackinfo"]
            send_mail(needf[0])
            current = len(needf)
        except Exception as e:

            print("\nThe data you have provided is not matching any current shipment.")
            command = input("Type 0 to try again, \nType 1 to exit. ")
            if command == "1":
                print("Goodbye!\n")
                sys.exit(1)
            again = True
        if not again:
            return


def listener():
    global current
    while True:
        response = requests.request("POST", url, data=payload, headers=headers)
        json_data = json.loads(response.text)
        need = json_data["data"]["items"][0]["origin_info"]["trackinfo"]
        if len(need) > current:
            current += 1
            send_mail(need[0])
            print("done with updates going to sleep for 5 minutes\n")
        else:
            print("no updates going to sleep for 5 minutes\n")
        for i in tqdm(range(5)):
            sleep(60)
        print("done sleeping checking for updates\n")


def send_mail(newdata):
    """helper function for sending out emails"""
    msg = EmailMessage()
    msg["From"] = fromWho
    msg["To"] = toWho
    msg["Subject"] = 'Important update by your shipment tracking script!'
    my_massage = str(newdata)
    msg.set_content(f"New update!!!! \n {my_massage}")
    context = ssl.create_default_context()
    with smtplib.SMTP("smtp.gmail.com", port=587) as smtp:
        smtp.starttls(context=context)
        smtp.login(msg["From"], password)
        smtp.send_message(msg)
        print("I have just sent you Email!")


if __name__ == '__main__':
    first_login()
    listener()
