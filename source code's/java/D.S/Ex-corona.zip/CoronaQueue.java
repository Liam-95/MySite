/*
Data Structures
Assignment number: 
File Name : CoronaQueue.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
package corona;

public class CoronaQueue {

	Person[] data;
	int[] next;
	int[] prev;
	int[] ref; // the reference array
	int size; // the current number of subjects in the queue
	int head; // the index of the lists 'head'. -1 if the list is empty.
	int tail; // the index of the lists 'tail'. -1 if the list is empty.
	int free; // the index of the first 'free' element.

	/**
	 * Creates an empty data structure with the given capacity. The capacity
	 * dictates how many different subjects may be put into the data structure.
	 * Moreover, the capacity gives an upper bound to the ID number of a Person to
	 * be put in the data structure.
	 * 
	 */
	public CoronaQueue(int capacity) {
		this.data = new Person[capacity];
		this.next = new int[capacity];
		this.prev = new int[capacity];
		this.ref = new int[capacity + 1];
		this.next[next.length - 1] = -1;
		this.size = 0;
		this.head = -1;
		this.tail = -1;
		this.free = 0;
		for (int i = 0; i < capacity - 1; i++) {
			this.next[i] = i + 1;
		}
		for (int j = 0; j < capacity + 1; j++) {
			this.ref[j] = -1;
		}
	}

	/**
	 * Returns the size of the queue.
	 *
	 * @return the size of the queue
	 */
	public int size() {
		return this.size;
	}

	/**
	 * Inserts a given Person into the queue. Inesertion should be done at the tail
	 * of the queue. If the given person is already in the queue this function
	 * should do nothing. Throws an illegal state exception if the queue is full.
	 *
	 * @param p - the Person to be inserted.
	 * @throws IllegalStateException - if queue is full.
	 */
	public void enqueue(Person p) {
		int Newid = p.id;
		boolean newList = false;
		boolean report = validcCheck(p.id, data.length, ref, size);
		if (report) {
			return;
		}
		if (size == 0 || this.tail == -1) {
			newList = true;
		}
		data[free] = p;
		size++;
		ref[Newid] = free;
		prev[free] = -1;
		int tempFree = next[free];
		next[free] = tail;
		if (!newList) {
			prev[tail] = free;
		}
		tail = free;
		if (newList) {
			head = free;
		}
		free = tempFree;

	}

	/**
	 * Removes and returns a Person from the queue. person removed is the one which
	 * sits at the head of the queue. If the queue is empty returns null.
	 */
	public Person dequeue() {
		if (this.size == 0) {
			return null;
		}
		Person ans = data[head];
		data[head] = null;
		next[head] = free;
		free = head;
		int tempHead = prev[head];
		if (tempHead != -1) {
			next[tempHead] = -1;
			head = tempHead;
		}
		if (ans != null) {
			ref[ans.id] = -1;
			size--;
		}
		if (size == 0) {
			head = -1;
			tail = -1;
		}
		return ans;
	}

	/**
	 * Removes a Person from (possibly) the middle of the queue.
	 * 
	 * Does nothing if the Person is not already in the queue. Recall that you are
	 * not allowed to traverse all elements in the queue. In particular no loops or
	 * recursion. Think about all the different edge cases and the variables which
	 * need to be updated. Make sure you understand the role of the reference array
	 * for this function.
	 * 
	 * @param p - the Person to remove
	 */
	public void remove(Person p) {
		int PersonId = p.id;
		// find location of the person to be removed
		int location = ref[PersonId];
		if (ref[PersonId] == -1) {
			return;
		}
		data[location] = null;
		if (prev[location] != -1) {
			next[prev[location]] = next[location];
		} else {
			tail = next[location];
		}
		if (next[location] != -1) {
			prev[next[location]] = prev[location];
		} else {
			head = prev[location];
		}
		next[location] = free;
		free = location;
		ref[PersonId] = -1;
		
		size--;

	}

	/**
	 * validating the insertion of a new person to the queue.
	 * 
	 * Does nothing if the Person is not already in the queue. if queue is full
	 * returns IllegalStateException.
	 * 
	 * @param p - the Person to inserted.
	 * @param l - the data array.
	 * @param r - the refrences array.
	 * @param s - the size of the queue.
	 */
	public boolean validcCheck(int p, int l, int[] r, int s) {
		int Newid = p;
		boolean isThere = false;
		if (Newid < r.length && r[Newid] != -1) {
			isThere = true;
			return isThere;
		}
		if (s == l || Newid >= r.length) {
			throw new IllegalStateException("sorry,queue is full, no vaccine for you.");
		}
		return isThere;
	}

	/*
	 * The following functions may be used for debugging your code.
	 */
	private void debugNext() {
		for (int i = 0; i < next.length; i++) {
			System.out.println(next[i]);
		}
		System.out.println();
	}

	private void debugPrev() {
		for (int i = 0; i < prev.length; i++) {
			System.out.println(prev[i]);
		}
		System.out.println();
	}

	private void debugData() {
		for (int i = 0; i < data.length; i++) {
			System.out.println(data[i]);
		}
		System.out.println();
	}

	private void debugRef() {
		for (int i = 0; i < ref.length; i++) {
			System.out.println(ref[i]);
		}
		System.out.println();
	}

	/*
	 * Test code; output should be: Aaron, ID number: 1 Baron, ID number: 2 Cauron,
	 * ID number: 3 Dareon, ID number: 4 Aaron, ID number: 1 Baron, ID number: 2
	 * Aaron, ID number: 1
	 * 
	 * Baron, ID number: 2 Cauron, ID number: 3
	 * 
	 * Aaron, ID number: 1 Dareon, ID number: 4
	 * 
	 * Aaron, ID number: 1 Cauron, ID number: 3
	 */
	public static void main(String[] args) {
		CoronaQueue demo = new CoronaQueue(4);
		Person a = new Person(1, "Aaron");
		Person b = new Person(2, "Baron");
		Person c = new Person(3, "Cauron");
		Person d = new Person(4, "Dareon");
		// Person bug = new Person(5, "exception");
		// demo.enqueue(bug);
		// first stage
		demo.enqueue(a);
		demo.enqueue(b);
		demo.enqueue(c);
		demo.enqueue(d);
		System.out.println(demo.dequeue());
		System.out.println(demo.dequeue());
		demo.enqueue(a);
		System.out.println(demo.dequeue());
		demo.enqueue(b);
		System.out.println(demo.dequeue());
		System.out.println(demo.dequeue());
		System.out.println(demo.dequeue());
		demo.enqueue(a);
		System.out.println(demo.dequeue());

		// second stage
		System.out.println();
		demo.enqueue(a);
		demo.enqueue(b);
		demo.enqueue(c);
		demo.enqueue(d);
		demo.remove(a);
		System.out.println(demo.dequeue());
		demo.remove(d);
		System.out.println(demo.dequeue());

		// third stage
		System.out.println();
		demo.enqueue(a);
		demo.enqueue(b);
		demo.enqueue(c);
		demo.enqueue(d);
		demo.remove(b);
		demo.remove(c);
		System.out.println(demo.dequeue());
		System.out.println(demo.dequeue());

		// //forth stage
		System.out.println();
		demo.enqueue(a);
		demo.enqueue(b);
		demo.enqueue(c);
		demo.enqueue(d);
		demo.remove(b);
		demo.remove(d);
		System.out.println(demo.dequeue());
		System.out.println(demo.dequeue());

	}
}
