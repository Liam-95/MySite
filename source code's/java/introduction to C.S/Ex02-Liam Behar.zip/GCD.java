/*
Assignment number: 2.1
File Name : GCD.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
public class GCD  {

    public static void main (String[] args) { 

    	int firstNumber = Integer.parseInt (args [0]);
    	int secondNumber = Integer.parseInt (args [1]);

    	while (firstNumber != secondNumber) {
    		/*if (firstNumber > secondNumber) {
    			firstNumber = firstNumber - secondNumber;
    		} else {
    			secondNumber = secondNumber - firstNumber;
    		}*/

    		if (firstNumber != secondNumber) {
    		
    			while (firstNumber > secondNumber) {
    			firstNumber = firstNumber - secondNumber;
    			}

    			while (secondNumber > firstNumber ) {
    			secondNumber = secondNumber - firstNumber;		
    			}
    		}

    	}		System.out.println ( "the GCD is " + secondNumber);
    }
}