/*
Assignment number: 2.2
File Name : Pi.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
public class Pi  {

    public static void main (String[] args) { 

    	int first = Integer.parseInt (args [0]);
    	int second = Integer.parseInt (args [1]);
        double count = first-1;
        double root = Math.sqrt(12);
        
        while (count <= second-1) {
            double series = 0;

            for ( double k = 0 ;  k <= count; k++) {

                double dynamic = (Math.pow((-3),-k)) / (2*k + 1);
                series = dynamic + series;
            } 

            count++;
            System.out.println("n = " + (int) count + ":" + " PI = " + root*series);
        }   
    }
}