/*
Assignment number: 2.3
File Name : MaxIntPalindrome.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
public class MaxIntPalindrome {

	public static void main(String[] args) {
		int big = 0;
		for (int i = 100; i <= 999; i++) {
			for (int j = 100; j <= 999; j++) {
				int product = i * j;
				boolean productCheck = isPalindrome(product);
				if (productCheck && product > big) {
					big = product;

				}
			}
		}
		System.out.println(big);
	}

	// method for checking if a number is numeric Palindrome //
	private static boolean isPalindrome(int check) {

		boolean isPalindrome = true;

		String sizeToString = " ";

		sizeToString = Integer.toString(check);

		int size = sizeToString.length();

		int mid = size / 2;

		for (int i = 0; i < mid; i++) {

			if (sizeToString.charAt(i) != sizeToString.charAt(size - i - 1)) {

				isPalindrome = false;

			}
		}
		return (isPalindrome);
	}
}