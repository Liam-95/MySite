/*
Assignment number: 2.4
File Name : Dices.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
public class Dices {

    public static void main(String[] args) {
        int numberOfThrows = Integer.parseInt(args[0]);
        int dicePotential = Integer.parseInt(args[1]);
        int numberOfSums = Integer.parseInt(args[2]);
        double calcSum = 0;
        double average = 0;

        for (int j = 0; j < numberOfSums; j++) {
            calcSum = calcSum + dice_sum(numberOfThrows, dicePotential);
        }
        average = calcSum / numberOfSums;

        System.out.println(average);
    }

    private static int dice(int dicePotential) {
        int actualSize =  (int)Math.ceil(Math.random() * dicePotential);
        return actualSize;
    }

    private static int dice_sum(int numberOfThrows, int diceSize) {
        int sum = 0;
        for (int i = 0; i < numberOfThrows; i++) {
            sum = sum + dice(diceSize);
        }
        return sum;
    }
}