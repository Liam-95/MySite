/*
Assignment number: 9.2
File Name : LinkedList.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
package linkedlist;

/**
 * Represents a list of Nodes.
 */
public class LinkedList<T> {

	private Node<T> first = null; // pointer to the first (dummy) node of this list
	private Node<T> last = null; // pointer to the last node of this list
	private int size = 0; // number of elements in this list */

	/**
	 * Constructs a new list.
	 */
	public LinkedList() {
		this.first = new Node(null);
	}

	/**
	 * Creates a new Node object that points to the given object, and inserts the
	 * node at the given index in this list.
	 * <p>
	 * If the given index is 0, the new node becomes the first node in this list.
	 * <p>
	 * If the given index equals the list's size, the new node becomes the last node
	 * in this list.
	 * 
	 * @param insert the object to be inserted into the list
	 * @param index  the index before which the object should be inserted
	 * @throws IllegalArgumentException if index is negative or greater than the
	 *                                  list's size
	 */
	public void add(int index, T insert) {
		if (index < 0 || index > this.size) {
			throw new IllegalArgumentException();
		}

		if (index == 0) {
			this.addFirst(insert);
			return;
		}
		if (index == this.size) {
			this.addLast(insert);
			return;
		}
		Node<T> mid = this.first.next;
		for (int i = 0; i < index; i++) {
			mid = mid.next;
		}
		Node<T> toInsert = new Node<T>(insert);
		toInsert.next = mid.next;
		mid.next = toInsert;
		this.size++;
	}

	/**
	 * Creates a new node with a reference to the given object, and appends it to
	 * the end of this list(the node will become the list's last node). The running
	 * time of this method must be O(1).
	 * 
	 * @param insert the given object
	 */
	public void addLast(T insert) {
		Node<T> theLast = new Node<T>(insert);
		if (this.last == null) {
			this.last = theLast;
			this.first.next = theLast;
		} else {
			this.last.next = theLast;
			this.last = theLast;
		}
		size++;
	}

	/**
	 * Creates a new node with a reference to the given object, and inserts it at
	 * the beginning of this list (the node will become the list's first node). The
	 * running time of this method must be O(1).
	 * 
	 * @param insert the given object
	 */

	public void addFirst(T insert) {
		Node<T> toInsert = new Node<T>(insert);
		toInsert.next = this.first.next;
		this.first.next = toInsert;
		if (this.last == null) {
			this.last = toInsert;
		}
		this.size++;
	}

	/**
	 * 
	 * Gets the object located at the given index in this list.
	 * 
	 * @param index the index of the retrieved object
	 * @return the object at the given index
	 * @throws IllegalArgumentException if index is negative or greater than or
	 *                                  equal to size
	 */
	public T get(int index) {
		if (index < 0 || index >= this.size) {
			throw new IllegalArgumentException();
		}
		Node<T> get = this.first.next;
		for (int i = 0; i < index; i++) {
			get = get.next;
		}
		return get.data;
	}

	/**
	 * Gets the index of the node pointing to the given object.
	 * 
	 * @param t the given object
	 * @return the index of the first occurrence of the object, or -1 if the object
	 *         is not in this list
	 */
	public int indexOf(T t) {
		Node<T> check = this.first.next;
		for (int i = 0; i < this.size; i++) {
			if (check.data.equals(t)) {
				return i;
			}
			check = check.next;
		}
		return -1;
	}

	/**
	 * Removes from this list the first occurrence of a node pointing to the given
	 * object.
	 * 
	 * @param remove the object that should be removed from the list
	 * @throws IllegalArgumentException if the given memory block is not in this
	 *                                  list
	 */
	public void remove(T remove) {
		Node<T> remo = this.first.next;
		int index = indexOf(remove);
		if (index == -1) {
			throw new IllegalArgumentException();
		}
		for (int i = 0; i < index; i++) {
			remo.next = remo.next.next;
		}
		size--;

	}

	/**
	 * Returns an iterator over this list, starting with the first element.
	 */
	public LinkedListIterator<T> iterator() {
		return new LinkedListIterator<T>(first.next);
	}

	/**
	 * A textual representation of this list, useful for debugging.
	 */
	public String toString() {
		Node text = first.next;
		String textual = "";
		for (int i = 0; i < size; i++) {
			textual += text + " ";
			text = text.next;
		}
		return textual;
	}
}