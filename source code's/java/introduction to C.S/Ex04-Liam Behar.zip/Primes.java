/*
Assignment number: 4.2
File Name : Primes.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/
public class Primes {
    public static void main(String[] args) {
        int upTo = Integer.parseInt(args[0]);
        boolean[] forPrint = sieveOfSundaram(upTo);
        System.out.println("the prime numbers up to " + upTo + " are:");
        for (int i = 0; i < forPrint.length; i++) {
            if (forPrint[i]) {
                System.out.print(i + " ");
            }
        }

    }

    /*
     * Returns a boolean array of length N in which the element at index i is true
     * if i is a prime and false otherwise.
     */
    private static boolean[] sieveOfSundaram(int N) {
        int size = (N - 2) / 2;
        boolean[] temp = new boolean[N+1];
        for (int i = 1; i < N; i++) {
            temp[i] = true;
        }

        for (int j = 1; j < size; j++) {
            for (int i = 1; i <= j; i++) {
                int notPrime = j+i+2*i*j;
                if (notPrime <= N) {
                    temp[notPrime] = false;
                }
            }
        }

        boolean[] ans = new boolean[N+1];
        for (int i = 0; i < ans.length; i++) {
            ans[i] = false;
        }
        ans[2] = true;
        for (int i = 0; i < temp.length; i++) {
            if (temp[i]) {
                int prime = i*2+1;
                if (prime <= N) {
                    ans[prime] = true;
                }
            }
        }
        return ans;
    }
}