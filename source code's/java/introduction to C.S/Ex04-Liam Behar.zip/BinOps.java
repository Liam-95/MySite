/*
Assignment number: 4.1
File Name : BinOps.java
Name : Liam Behar
Email : liam.behar@post.idc.ac.il
*/

/**
 * This class features various algebraic operations on binary values. Each
 * binary value is represented by an array of n integer values, each being 0 or
 * 1. We call such arrays "binary arrays". The power of index 0 is (n - 1). The
 * power of index (n - 1) is 0.
 */
public class BinOps {

	static final int n = 16;

	// Assumes that args[0] and args[2] are non-negative integers, and
	// that args[1] is either "add" or "mult".
	// Converts args[0] and args[1] to binary arrays, performs the add/mult
	// operation, and prints the decimal value of the resulting binary array.
	public static void main(String args[]) {
		int firstNumber = Integer.parseInt(args[0]);
		String mathOps = (args[1]);
		int secondNumber = Integer.parseInt(args[2]);
		String add = "add";
		String mult = "mult";
		if (mathOps.equals(add)) {
			int[] firstNumber2Bin = int2bin(firstNumber);
			int[] secondNumber2Bin = int2bin(secondNumber);
			int[] firstAndSecondbin = add(firstNumber2Bin, secondNumber2Bin);
			int sum = bin2int(firstAndSecondbin);
			System.out.println(sum);
		} else if (mathOps.equals(mult)) {
			int[] firstNumber2Bin = int2bin(firstNumber);
			int[] secondNumber2Bin = int2bin(secondNumber);
			int[] firstAndSecondbin = mult(firstNumber2Bin, secondNumber2Bin);
			int product = bin2int(firstAndSecondbin);
			System.out.println(product);
		}
		//tests();
	}

	// Function testers
	public static void tests() {
		int[] b1 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1 }; // 13
		int[] b2 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0 }; // 6
		System.out.println(bin2String(b1)); // "0000000000001101"
		System.out.println(bin2String(b2)); // "0000000000000110"
		System.out.println(bin2String(add(b1, b2))); // "0000000000010011"
		System.out.println(bin2String(leftShift(b2))); // "0000000000001100"
		System.out.println(bin2String(mult(b1, b2))); // "0000000001001110"

		System.out.println("new case:");
		int[] a1 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1 }; // 15
		int[] a2 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1 }; // 5
		System.out.println(bin2String(a1)); // "0000000000001111"
		System.out.println(bin2String(a2)); // "0000000000000101"
		System.out.println(bin2String(add(a1, a2))); // "0000000000010100"
		System.out.println(bin2String(leftShift(a2))); // "0000000000001010"
		System.out.println(bin2String(mult(a1, a2))); // "0000000001001011"
	}

	/**
	 * Returns the sum of the two given binary arrays, as a binary array. Ignores
	 * the overflow bit, if there is one. Assumes array values are all 0 or 1.
	 * Example 1 (no overflow): if x = {0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,1} and y =
	 * {0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0}, returns:
	 * {0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,1}. Example 2 (overflow): if x =
	 * {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1} and y = {1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1},
	 * returns: {0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0}.
	 */
	public static int[] add(int[] x, int[] y) {
		int[] ans = new int[x.length];
		int carry = 0;
		for (int i = x.length - 1; i >= 0; i--) {
			if (x[i] == 1 && y[i] == 1) {
				if (carry == 1) {
					ans[i] = 1;
				} else {
					carry = 1;
				}
			} else if (x[i] == 1 || y[i] == 1) {
				if (carry == 0) {
					ans[i] = 1;
				}
			} else if (carry == 1) {
				carry = 0;
				ans[i] = 1;
			}
		}
		return ans;
	}

	/**
	 * Returns the product of the two given binary arrays, as a binary array.
	 * Ignores the overflow bit, if there is one. Assumes array values are all 0 or
	 * 1. Example: if x = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0} and y =
	 * {0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1}, returns:
	 * {0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0}.
	 */
	public static int[] mult(int[] x, int[] y) {
		int[] ans = new int[x.length];
		int[] shifty = x;
		int iterations = 0;
		int timesShifted = 0;
		int temp = 0;
		for (int i = x.length - 1; i >= 0; i--) {
			if (y[i] == 1) {
				for (int j = 0; j < iterations - timesShifted; j++) {
					shifty = leftShift(shifty);
					temp++;
				}
				timesShifted = temp;
				ans = add(ans, shifty);
			}
			iterations++;
		}
		return ans;
	}
	/**
	 * Returns the binary array that represents the given int value. If the given
	 * int value exceeds the n-bit representation, ignores all the overflow bits.
	 * Assumes input value is a non-negative integer. Example: if x = 6, returns:
	 * {0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0}.
	 */
	public static int[] int2bin(int x) {
		int quotient = 0;
		int modulo = 0;
		int[] ans = new int[n];
		int i = ans.length - 1;
		while (x > 0) {
			quotient = (int) (x / 2);
			modulo = x % 2;
			ans[i] = modulo;
			x = quotient;
			i--;
		}
		return ans;
	}

	/**
	 * Returns the integer value of the given binary array. Assumes array values are
	 * all 0 or 1. For example: if x = {0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1}, returns:
	 * 9.
	 */
	public static int bin2int(int[] x) {
		int[] powersOfTwo = new int[x.length];
		int bit = 0;
		int sum = 0;
		for (int k = (powersOfTwo.length - 1); k > 0; k--) {
			powersOfTwo[k] = (int) Math.pow(2, bit);
			bit++;
		}
		for (int i = 0; i < x.length; i++) {
			sum += x[i] * powersOfTwo[i];
		}
		return sum;
	}

	/**
	 * Returns a binary array which is the given binary array, shifted one position
	 * to the left. Ignores the overflow bit, if there is one. Assumes array values
	 * are all 0 or 1. Example 1 (no overflow): if x =
	 * {0,0,0,0,0,0,0,0,1,1,1,0,0,1,0,0}), returns:
	 * {0,0,0,0,0,0,0,1,1,1,0,0,1,0,0,0}). Example 2 (overflow): if x =
	 * {1,0,1,0,0,0,0,0,0,0,0,0,0,1,0,1}), returns:
	 * {0,1,0,0,0,0,0,0,0,0,0,0,1,0,1,0}).
	 */
	public static int[] leftShift(int[] x) {
		int[] shift = new int[x.length];
		for (int i = 0; i < x.length - 1; i++) {
			if (shift[i] < x.length - 1) {
				shift[i] = x[i + 1];
			} else
				shift[i] = 0;
		}
		return shift;
	}

	/**
	 * Returns the given binary array, as a string. Useful for debugging purposes.
	 * Assumes array values are all 0 or 1. Example: if x =
	 * {0,0,0,1,1,0,0,0,0,0,0,0,0,1,0,1}), returns: "0001100000000101".
	 */
	public static String bin2String(int[] x) {
		String ans = "";
		for (int i = 0; i < x.length; i++) {
			ans += x[i];
		}
		return ans;
	}
}