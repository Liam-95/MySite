#include "C:\Users\liamb\OneDrive\Desktop\studys\First year\Semester 2\System Programing in C\9\expenseReport.c"
ExpenseReport strToExpenseItem(const char *str);
double AmountStringToDouble(const char *numStr, int index);
int numLeadingZeros(const char *numStr, int index);
int NumDot(const char *numStr);
#define MAX_line_LENGHT 301
// global int for the use of AmountStringToDouble
int dotIndex = -1;
int main(int argc, char **argv)
{
    //check if the program should read the expense items from the standard input
    char bufferLine[MAX_line_LENGHT];
    FILE *f = NULL;
    if (argc > 1)
    {
        f = fopen(argv[1], "r");
        int sizeArg1 = strlen(argv[1]);
        if ((*argv[1] != '-' && f == NULL) || (f == NULL && sizeArg1 > 1))
        {
            fprintf(stderr, "Cannot open %s for reading", argv[1]);
            return 1;
        }
    }
    int counterBadLines = 0;
    int firstExpenseReport = 1;
    int twiceBreakLine = -1;
    int bad = -1;
    int made = -1;
    int needToFree = -1;
    int stdinInput = 1;
    ExpenseReport current = NULL;
    ExpenseReport next = NULL;
    ExpenseReport expenseMerged = NULL;
    if (!f)
    {
        while (fgets(bufferLine, MAX_line_LENGHT, stdin))
        {
            char *end = strchr(bufferLine, '\0');
            end[-1] = '\0';
            // if line start with breaking line (#)
            if (bufferLine[0] == '#')
            {
                // if we encounter break line twice in a row
                if (twiceBreakLine == 1)
                {
                    printf("No expenses to report\n");
                }
                else
                {
                    // if there are reports to print ,then print and reset the ExpenseReport
                    if (current)
                    {
                        printExpenseReport(current);
                        needToFree = 1;
                    }
                    twiceBreakLine = 1;
                }
                // increment bad lines counter
                strcpy(bufferLine, &bufferLine[1]);
                printf("%s\n", bufferLine);
                if (needToFree != -1)
                {
                    freeExpenseReport(current);
                    needToFree = -1;
                    firstExpenseReport = 1;
                }
            }
            // not breaking line , merge the expenseReports.
            else
            {
                twiceBreakLine = -1;
                // if the firstExpenseReport was found , no merging nedded.
                if (firstExpenseReport == 1)
                {
                    current = strToExpenseItem(bufferLine);
                    if (!current)
                    {
                        bad = 1;
                        counterBadLines++;
                        continue;
                    }
                    needToFree = 1;
                }
                else
                {
                    // creating next ExpenseReport
                    next = strToExpenseItem(bufferLine);
                    if (!next)
                    {
                        bad = 1;
                        counterBadLines++;
                        continue;
                    }
                    // merge current ExpenseReport with the new one.
                    expenseMerged = mergeExpenseReports(current, next);
                    if (!expenseMerged)
                    {
                        // if merge failed , free next and current print to stderr and exit 2
                        freeExpenseReport(next);
                        freeExpenseReport(current);
                        fprintf(stderr, "Out of memory\n");
                        return 2;
                    }
                    if (next)
                    {
                        freeExpenseReport(next);
                    }
                    current = expenseMerged;
                    needToFree = 1;
                    twiceBreakLine = -1;
                }
                firstExpenseReport = -1;
            }
        }
        if (needToFree == 1)
        {
            printExpenseReport(current);
            freeExpenseReport(current);
            needToFree = -1;
        }
        else if (needToFree == -1)
        {
            printf("No expenses to report\n");
        }
        fclose(stdin);
    }
    else
    {
        stdinInput = -1;
        while (fgets(bufferLine, MAX_line_LENGHT, f))
        {
            char *end = strchr(bufferLine, '\0');
            end[-1] = '\0';
            // if line start with breaking line (#)
            if (bufferLine[0] == '#')
            {
                // if we encounter break line twice in a row
                if (twiceBreakLine == 1)
                {
                    printf("No expenses to report\n");
                }
                else
                {
                    // if there are reports to print ,then print and reset the ExpenseReport
                    if (current)
                    {
                        printExpenseReport(current);
                        needToFree = 1;
                    }
                    twiceBreakLine = 1;
                }
                // increment bad lines counter
                strcpy(bufferLine, &bufferLine[1]);
                printf("%s\n", bufferLine);
                if (needToFree != -1)
                {
                    freeExpenseReport(current);
                    needToFree = -1;
                    firstExpenseReport = 1;
                }
            }
            // not breaking line , merge the expenseReports.
            else
            {
                // if the firstExpenseReport was found , no merging nedded.
                if (firstExpenseReport == 1)
                {
                    current = strToExpenseItem(bufferLine);
                    if (!current)
                    {
                        bad = 1;
                        counterBadLines++;
                        continue;
                    }
                    needToFree = 1;
                    twiceBreakLine = -1;
                }
                else
                {
                    // creating next ExpenseReport
                    next = strToExpenseItem(bufferLine);
                    if (!next)
                    {
                        bad = 1;
                        counterBadLines++;
                        continue;
                    }
                    // merge current ExpenseReport with the new one.
                    expenseMerged = mergeExpenseReports(current, next);
                    if (!expenseMerged)
                    {
                        // if merge failed , free next and current print to stderr and exit 2
                        freeExpenseReport(next);
                        freeExpenseReport(current);
                        fprintf(stderr, "Out of memory\n");
                        return 2;
                    }
                    if (next)
                    {
                        freeExpenseReport(next);
                    }
                    current = expenseMerged;
                    needToFree = 1;
                    twiceBreakLine = -1;
                }
                firstExpenseReport = -1;
            }
        }
        if (needToFree == 1)
        {
            printExpenseReport(current);
            freeExpenseReport(current);
            needToFree = -1;
        }
        else if (needToFree == -1)
        {
            printf("No expenses to report\n");
        }
        fclose(f);
    }
    if (expenseMerged)
    {
        freeExpenseReport(expenseMerged);
    }
    if (bad == 1 && stdinInput == -1)
    {
        fprintf(stderr, "File %s contains %d invalid lines, which were ignored\n", argv[1], counterBadLines);
        return 3;
    }
    else if (bad == 1 && stdinInput == 1)
    {
        fprintf(stderr, "File stdin contains %d invalid lines, which were ignored\n", counterBadLines);
        return 3;
    }
    return 0;
}
ExpenseReport strToExpenseItem(const char *str)
{
    int i = 0;
    char a = str[i];
    // iterate over the char array until <token1>
    while ((a == ' ') && i < strlen(str))
    {
        i++;
        a = str[i];
    }
    //found the first char of token1
    int indexToken1 = i;
    const char *foundDate = &str[i];
    // iterate over the char array until <space2>
    i++;
    char b = str[i];
    while (b != ' ' && i < strlen(str))
    {
        i++;
        b = str[i];
    }
    //found the first char of <space2>
    int indexSpace2 = i;
    // iterate over the char array until <token2>
    i++;
    char c = str[i];
    while (c == ' ' && i < strlen(str))
    {
        i++;
        c = str[i];
    }
    //found the first char of <token2>
    int indexToken2 = i;
    const char *foundAmount = &str[i];
    // iterate over the char array until <Space3>
    i++;
    char d = str[i];
    while (d != ' ' && i < strlen(str))
    {
        i++;
        d = str[i];
    }
    // if no space3 was found return NULL
    if (i == strlen(str))
    {
        return NULL;
    }
    //found the first char of <space3>
    int indexSpace3 = i;
    // iterate over the char array until <Token3>
    i++;
    char e = str[i];
    while ((e == ' ') && i < strlen(str))
    {
        i++;
        e = str[i];
    }
    //found the first char of <Token3>
    int indexToken3 = i;
    const char *foundDescription = &str[i];
    if (indexToken3 - indexSpace3 == 0)
    {
        return NULL;
    }
    if (strlen(str) == 0)
    {
        return NULL;
    }
    double newAmount = AmountStringToDouble(foundAmount, indexSpace3 - (indexToken2));
    if (newAmount < 0)
    {
        return NULL;
    }
    ExpenseReport ans = newExpenseItem(newAmount, foundDate, foundDescription);
    if (ans == NULL)
    {
        return NULL;
    }
    return ans;
}
// compute the double input from the string
double AmountStringToDouble(const char *numStr, int token2Size)
{
    // int test = token2Size;
    int i = 0;
    double num = 0;
    double afterDot = 0;
    char c = numStr[i];
    int counter = 0;
    char t;
    int index = 0;
    int good = 1;
    int lead = numLeadingZeros(numStr, token2Size);
    if (lead == -1)
    {
        return -1;
    }
    //compute the double
    for (int i = lead; i < token2Size; i++)
    {
        c = numStr[i];
        if ((c > '9' || c < '0') && c != '.')
        {
            good = -1;
        }
        if (c == ' ')
        {
            index = i;
            break;
        }
        if (c != '.')
        {
            num = num * 10 + (c - '0');
        }
        else
        {
            index = i;
            break;
        }
    }
    double divider = 10;
    if (index != 0)
    {
        for (int j = index + 1; j < token2Size; j++)
        {
            t = numStr[j];
            if (t > '9' || t < '0')
            {
                good = -1;
            }
            afterDot = afterDot * 10 + (t - '0');
            counter++;
        }
        int min = -1;
        if (counter - 1 <= 16 - dotIndex)
        {
            min = counter - 1;
        }
        else
        {
            min = 16 - (token2Size - dotIndex);
        }
        for (int k = 0; k < min; k++)
        {
            divider = divider * 10;
        }
        afterDot = afterDot / divider;
    }
    if (good == -1)
    {
        return -1;
    }
    return (num + afterDot);
}
int numLeadingZeros(const char *numStr, int token2Size)
{
    int dot = NumDot(numStr);
    if (dot == -1)
    {
        return -1;
    }
    if (dot == 0)
    {
        dot = -1;
    }
    if (numStr[0] != '0')
    {
        return 0;
    }
    char c;
    int counter = 0;
    int i = 0;
    int zeroCounter = 0;
    while (i < token2Size)
    {
        c = numStr[i];
        if (c != '0')
        {
            if (c == '.')
            {
                counter--;
            }
            break;
        }
        zeroCounter++;
        counter++;
        i++;
    }
    // if the number is only zeros and there is no dot
    if (dot == -1 && zeroCounter == token2Size)
    {
        counter--;
    }
    return counter;
}
int NumDot(const char *numStr)
{
    int i = 0;
    char c = numStr[i];
    int dotCounter = 0;
    while (c != ' ')
    {
        i++;
        c = numStr[i];
        if (c == '.')
        {
            dotIndex = i;
            dotCounter++;
        }
    }
    if (dotCounter > 1)
    {
        return -1;
    }
    return dotIndex;
}
