typedef struct ExpenseReport *ExpenseReport;
ExpenseReport newExpenseItem(double amount, const char *date, const char *description);
void freeExpenseReport(ExpenseReport expenseRep);
ExpenseReport mergeExpenseReports(ExpenseReport expenseRep1, ExpenseReport expenseRep2);
int numExpenseItems(ExpenseReport expenseRep);
void printExpenseReport(ExpenseReport expenseRep);
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define DATE_SIZE 8

struct ExpenseReport
{
    double totalAmount;
    char startDate[DATE_SIZE];
    char endDate[DATE_SIZE];
    char *description;
};
//constructor function newExpenseItem which creates a new ExpenseReport object
ExpenseReport newExpenseItem(double amount, const char *date, const char *description)
{
    if (amount <= 0)
    {
        return NULL;
    }
    for (int i = 0; i < DATE_SIZE; i++)
    {
        char c = date[i];
        if ((c < '0') || (c > '9'))
        {
            return NULL;
        }
    }
    char a = date[0];
    char b = date[1];
    char c = date[2];
    char d = date[3];
    char e = date[4];
    char f = date[5];
    char g = date[6];
    char h = date[7];
    // check the year coded in the date.
    if ((a > '2' && a < '1') || (b != '9' && b != '0') || (c == '3' || c == '4'))
    {
        return NULL;
    }
    if (a == '2' && b == '0' && c == '2' && d != '0')
    {
        return NULL;
    }
    if (a == '1' && b == '9' && c < '5')
    {
        return NULL;
    }
    // check the month coded in the date.
    if (e != '0' && e != '1')
    {
        return NULL;
    }
    if (e == '0' && f == '0')
    {
        return NULL;
    }
    if (e == '1' && f > '2')
    {
        return NULL;
    }
    // check the day coded in the date.
    if ((g > '3') || (g == '0' && h == '0') || (g == '3' && h > '1'))
    {
        return NULL;
    }
    char *line = strchr(description, '\n');
    if (line != NULL)
    {
        return NULL;
    }
    // all arguments are good to go, construct the ExpenseReport.
    ExpenseReport newExpense;
    newExpense = malloc(sizeof(struct ExpenseReport));
    if (!newExpense)
    {
        return NULL;
    }
    newExpense->description = malloc((strlen(description) * sizeof(char)) + 1);
    if (!newExpense->description)
    {
        free(newExpense);
        return NULL;
    }
    // fill up the fileds with the data we recived
    newExpense->totalAmount = amount;
    strncpy(newExpense->startDate, date, DATE_SIZE);
    strncpy(newExpense->endDate, date, DATE_SIZE);
    strcpy(newExpense->description, description);
    return newExpense;
}
// destructor function which frees all space allocated by a given ExpenseReport object.
void freeExpenseReport(ExpenseReport expenseRep)
{
    free(expenseRep->description);
    free(expenseRep);
    return;
}
// fixed the name of expenseRep1
ExpenseReport mergeExpenseReports(ExpenseReport expenseRep1, ExpenseReport expenseRep2)
{
    int early = strncmp(expenseRep1->startDate, expenseRep2->startDate, DATE_SIZE);
    int later = strncmp(expenseRep1->endDate, expenseRep2->endDate, DATE_SIZE);
    double newtotal = expenseRep1->totalAmount + expenseRep2->totalAmount;
    int size = strlen(expenseRep1->description) + strlen(expenseRep2->description);
    char *des1 = expenseRep1->description;
    int sizeDescriptionInOld = strlen(des1);
    expenseRep1->description = malloc(size * sizeof(char) + 2);
    if (!expenseRep1->description)
    {
        expenseRep1->description = des1;
        return NULL;
    }
    if (early > 0)
    {
        strncpy(expenseRep1->startDate, expenseRep2->startDate, DATE_SIZE);
    }
    if (later < 0)
    {
        strncpy(expenseRep1->endDate, expenseRep2->endDate, DATE_SIZE);
    }
    expenseRep1->totalAmount = newtotal;
    strncpy(expenseRep1->description, des1, sizeDescriptionInOld);
    expenseRep1->description[sizeDescriptionInOld] = '\n';
    expenseRep1->description[sizeDescriptionInOld + 1] = '\0';
    if (expenseRep1->description != expenseRep2->description)
    {
        strcat(expenseRep1->description, expenseRep2->description);
    }
    else
    {
        strcat(expenseRep1->description, des1);
    }
    free(des1);
    return expenseRep1;
}
int numExpenseItems(ExpenseReport expenseRep)
{
    char *newLine;
    newLine = strchr(expenseRep->description, '\n');
    int counter = 1;
    while (newLine != NULL)
    {
        counter++;
        newLine = strchr(newLine + 1, '\n');
    }
    return counter;
}
void printExpenseReport(ExpenseReport expenseRep)
{
    char startForPrint[11];
    char endForPrint[11];
    for (int i = 6; i < 10; i++)
    {
        startForPrint[i] = expenseRep->startDate[i - 6];
        endForPrint[i] = expenseRep->endDate[i - 6];
    }
    startForPrint[5] = '/';
    endForPrint[5] = '/';
    for (int i = 3; i < 5; i++)
    {
        startForPrint[i] = expenseRep->startDate[i + 1];
        endForPrint[i] = expenseRep->endDate[i + 1];
    }
    startForPrint[2] = '/';
    endForPrint[2] = '/';
    for (int i = 0; i < 2; i++)
    {
        startForPrint[i] = expenseRep->startDate[i + 6];
        endForPrint[i] = expenseRep->endDate[i + 6];
    }
    int numItems = numExpenseItems(expenseRep);
    double finalAmount = expenseRep->totalAmount;
    startForPrint[10] = '\0';
    endForPrint[10] = '\0';
    printf("%3d %s %s %s %s%s\n", numItems, "expense(s) reported between", startForPrint, "and", endForPrint, ":");
    printf("\n%s", expenseRep->description);
    printf("\n%s %0.1lf %s\n", "Total amount:", finalAmount, "NIS");
}