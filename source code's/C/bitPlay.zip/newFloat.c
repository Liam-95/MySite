#include <stdio.h>

int rightBits(int n, int numBits);
int leftBits(int n, int numBits);
int getBit(int n, int numBits);
int getExponent(int newFloatNum);
int getMantissa(int newFloatNum);
int getNewFloat(int mantissa, int exponent);
int newFloatSum(int newFloatNum1, int newFloatNum2);
double newFloatToDouble(int newFloat);
#define NUM_EXP_BITS 4
#define NUM_MAN_BITS (sizeof(int) * 8 - NUM_EXP_BITS)

void main()
{
}

int newFloatSum(int newFloatNum1, int newFloatNum2)
{
    int mantissaMaxInt = 0;
    for (int i = 0; i < NUM_MAN_BITS; i++)
    {
        mantissaMaxInt = mantissaMaxInt + (1 << i);
    }
    int man1 = getMantissa(newFloatNum1);
    int exp1 = getExponent(newFloatNum1);
    int man2 = getMantissa(newFloatNum2);
    int exp2 = getExponent(newFloatNum2);
    int newSumFloat = 0;
    int finalNewSumFloat = 0;
    int sumAll = 0;
    int leftman1 = getBit(man1, NUM_MAN_BITS - 1);
    int leftman2 = getBit(man2, NUM_MAN_BITS - 1);
    int expo1 = getExponent(newFloatNum1);
    int expo2 = getExponent(newFloatNum2);

    if ((leftman1 == 0 && expo1 != 0) || (leftman2 == 0 && expo2 != 0))
    {

        return -1;
    }
    if (exp1 > exp2)
    {
        int sumExp = (exp1 - exp2);
        int powerOfSumExp = 1 << sumExp;
        int division = man2 / powerOfSumExp;
        sumAll = division + man1;
        newSumFloat = (exp1 << NUM_MAN_BITS) + sumAll;
        finalNewSumFloat = getNewFloat(getMantissa(newSumFloat), getExponent(newSumFloat));
    }
    else
    {
        int sumExp = (exp2 - exp1);
        int powerOfSumExp = 1 << sumExp;
        int division = man1 / powerOfSumExp;
        sumAll = division + man2;
        newSumFloat = (exp2 << NUM_MAN_BITS) + sumAll;
        finalNewSumFloat = getNewFloat(getMantissa(newSumFloat), getExponent(newSumFloat));
    }
    if (sumAll > mantissaMaxInt)
    {
        return -1;
    }
    else
    {
        return finalNewSumFloat;
    }
}

int rightBits(int n, int numBits)
{

    if (numBits < 0)
    {
        return 0;
    }
    if (numBits >= 8 * sizeof(int))
    {
        return n;
    }
    else
    {
        int temp = -1 << numBits;
        int ans = n ^ temp;
        int ans3 = ~temp & ans;
        return ans3;
    }
}

int leftBits(int n, int numBits)
{
    int bit = sizeof(int) * 8;
    if (numBits <= 0)
    {
        return 0;
    }
    if (numBits >= bit)
    {
        return n;
    }
    if (n > 0)
    {
        int temp = n >> (bit - (numBits));
        return temp;
    }
    else
    {
        int temp = -1 << (bit - numBits);
        int ans1 = n & temp;
        int shift = ans1 >> 1;
        int temp2 = (-1) << (bit - 1);
        int ans2 = (shift) & (~temp2);
        int final = ans2 >> (bit - numBits - 1);
        return final;
    }
}

int getBit(int n, int bitInd)
{
    int bit = sizeof(int) * 8 - 1;

    if (bitInd < 0)
    {
        return 0;
    }
    if (bitInd > bit)
    {
        return 0;
    }
    else
    {
        int ans1 = n >> (bitInd);
        int temp = -1 << 1;
        int ans2 = ans1 & ~temp;
        return ans2;
    }
}
int getExponent(int newFloatNum)
{
    return leftBits(newFloatNum, NUM_EXP_BITS);
}
int getMantissa(int newFloatNum)
{
    return rightBits(newFloatNum, NUM_MAN_BITS);
}
int getNewFloat(int mantissa, int exponent)
{
    int exponentMaxInt = 0;
    for (int i = 0; i < NUM_EXP_BITS; i++)
    {
        exponentMaxInt = exponentMaxInt + (1 << i);
    }
    // size of actuall bits in the mantissa
    int size = 0;
    int temp = mantissa;
    while (temp != 0)
    {
        temp = temp >> 1;
        size++;
    }
    // remaning bits space in the mantissa vector
    int left = NUM_MAN_BITS - size;
    // checking the conditions
    if (left > 0 && exponent != 0)
    {
        // incresing the mantissa , decresing the exponent
        if (exponent > left)
        {
            mantissa = mantissa << left;
            exponent = exponent - left;
        }
        // incresing the manstissa,exp = 0
        else if (exponent <= left)
        {
            mantissa = mantissa << exponent;
            exponent = 0;
        }
        if (exponent > exponentMaxInt)
        {
            return -1;
        }
    }
    if (left < 0)
    {
        int temp = left;
        while (temp < 0)
        {
            mantissa = mantissa / 2;
            temp++;
        }
        if (exponent + (-left) <= exponentMaxInt)
        {
            exponent = exponent + (-left);
        }
        else
        {
            return -1;
        }
    }
    int newFloat = (exponent << NUM_MAN_BITS) + (mantissa);
    return newFloat;
}
double newFloatToDouble(int newFloat)
{

    int exponent = getExponent(newFloat),
        mantissa = getMantissa(newFloat);
    /*** check that the left-most bit in the mantissa
        is 1 when the exponent is > 0                  ***/
    if ((exponent > 0) && (mantissa >> (NUM_MAN_BITS - 1) == 0))
        return -1.0;

    /*** This loop computes 2^exponent efficiently
        by using at most 2 x log_2(exponent) multiplications
        After the i'th iteration of this while loop
        - temp holds 2^(2^i) (2.0 , 4.0 , 16.0 , 256.0 , ... )
        - num holds 2^x, where x is the integer represented
        by the right-most i bits of exponent
    ***/
    double temp = 2.0, num = 1.0;
    while (exponent)
    {
        if (exponent & 1)
            num *= temp;
        temp *= temp;
        exponent = exponent >> 1;
    } // end of while(exponent)

    /*** return 2^exp x mantissa  ***/

    return num * mantissa;
}